# Shrinks the images of Candid Krabs (Game305.vol), an IconBob game made for the Nintendo 3DS, that are too big
# for the Wii. Its eight 2400x1440 layers take about 24 MB once loaded, more than the Wii has free, and the game
# stops with "Out of memory"; and the Wii's graphics chip can't use a texture wider or taller than 1024 pixels, so
# they, and its two 1200x800 pictures of Mr. Krabs, couldn't be drawn anyway (they come out as stripes). Each is
# stored at a half or a third of its size, whichever first fits, with byte 0x18 of its header (padding) set to
# that, which the patch's image loader hook (code/image_hooks.S) reads to draw it at its full size again: the same
# picture on screen.
#   python3 shrink.py <Game305.vol> <out.vol>
import os
import struct
import sys

import numpy as np
from PIL import Image

import build
import logo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # wiivol.py, next to this file
import wiivol  # noqa: E402

MAX_TEXTURE = 1024  # the largest width and height of a texture

def scale_for(w, h):
    """The smallest scale (2-4, what image_hooks.S takes) that brings w and h within a texture's limit."""
    for s in (2, 3, 4):
        if w % s == 0 and h % s == 0 and w // s <= MAX_TEXTURE and h // s <= MAX_TEXTURE:
            return s
    raise ValueError('no scale fits %dx%d' % (w, h))

def rgb565(c):
    return ((c[..., 0].astype(np.uint32) >> 3) << 11) | ((c[..., 1].astype(np.uint32) >> 2) << 5) | (c[..., 2].astype(np.uint32) >> 3)

def expand565(v):
    r, g, b = (v >> 11) & 31, (v >> 5) & 63, v & 31
    return np.stack([(r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)], -1).astype(np.int32)

def cmpr_tiles(rgba):
    """CMPR tiles (8x8, four 4x4 DXT1 blocks each, raster order) of an RGBA array whose sides are multiples of 8.
    Each block's two colours are the darkest and brightest corners of its opaque pixels' box, always in 4-colour
    mode (the transparency is a separate alpha layer)."""
    h, w, _ = rgba.shape
    blocks = rgba.reshape(h // 8, 2, 4, w // 8, 2, 4, 4).transpose(0, 3, 1, 4, 2, 5, 6)  # ty tx by bx y x c
    px = blocks.reshape(-1, 16, 4).astype(np.int32)
    opaque = px[..., 3:4] > 0
    any_opaque = opaque.any(1)
    lo = np.where(opaque, px[..., :3], 255).min(1)
    hi = np.where(opaque, px[..., :3], 0).max(1)
    lo = np.where(any_opaque, lo, px[..., :3].min(1))
    hi = np.where(any_opaque, hi, px[..., :3].max(1))
    c0, c1 = rgb565(hi), rgb565(lo)
    swap = c0 < c1
    c0, c1 = np.where(swap, c1, c0), np.where(swap, c0, c1)
    p0, p1 = expand565(c0), expand565(c1)
    pal = np.stack([p0, p1, (2 * p0 + p1) // 3, (p0 + 2 * p1) // 3], 1)  # n 4 3
    d = ((px[:, :, None, :3] - pal[:, None, :, :]) ** 2).sum(-1)       # n 16 4
    idx = d.argmin(-1).astype(np.uint32)
    idx = np.where((c0 == c1)[:, None], 0, idx)
    bits = (idx << (30 - 2 * np.arange(16, dtype=np.uint32))).sum(1, dtype=np.uint64).astype(np.uint32)
    out = np.zeros((len(px), 8), dtype='>u1')
    out = np.concatenate([c0.astype('>u2').view('>u1').reshape(-1, 2), c1.astype('>u2').view('>u1').reshape(-1, 2),
                          bits.astype('>u4').view('>u1').reshape(-1, 4)], 1)
    data = out.reshape(-1, 32)  # four blocks a tile
    return [bytes(t) for t in data]

def i4_tiles(alpha):
    h, w = alpha.shape
    a = ((alpha.astype(np.int32) + 8) // 17).astype(np.uint8)
    tiles = a.reshape(h // 8, 8, w // 8, 8).transpose(0, 2, 1, 3).reshape(-1, 8, 4, 2)
    packed = (tiles[..., 0] << 4) | tiles[..., 1]
    return [bytes(t) for t in packed.reshape(-1, 32)]

def encode(img, header, alpha, scale):
    w, h = img.size
    pw, ph = (w + 7) // 8 * 8, (h + 7) // 8 * 8
    arr = np.zeros((ph, pw, 4), np.uint8)
    arr[:h, :w] = np.asarray(img)
    arr[h:, :w] = arr[h - 1:h, :w]
    arr[:, w:] = arr[:, w - 1:w]
    s1 = logo.write_stream(cmpr_tiles(arr))
    a_off = (0x20 + len(s1) + 31) // 32 * 32
    out = bytearray(header[:0x20])
    struct.pack_into('>HH', out, 8, w, h)
    cx, cy = struct.unpack('>hh', header[12:16])
    struct.pack_into('>hh', out, 12, cx // scale, cy // scale)
    struct.pack_into('>II', out, 16, 0x20, a_off)
    out[0x18] = scale
    out += s1
    out += b'\0' * (a_off - len(out))
    if alpha:
        out += logo.write_stream(i4_tiles(arr[..., 3]))
    return bytes(out)

def main(src, dst):
    orig = open(src, 'rb').read()
    _, _, ents = build.read_vol(orig)
    new = {}
    for e in ents:
        name, d = e['name'].decode('latin-1'), e['data']
        if not name.endswith('.image') or d[:4] != b'WIMG' or d[5] != 14 or d[0x18] != 0:
            continue
        w, h = struct.unpack('>HH', d[8:12])
        if w <= MAX_TEXTURE and h <= MAX_TEXTURE:
            continue
        scale = scale_for(w, h)
        alpha = d[6] != 0xFF
        img = wiivol.wimg(d).convert('RGBA')
        small = img.resize((w // scale, h // scale), Image.LANCZOS)
        data = encode(small, d, alpha, scale)
        check = wiivol.wimg(data).convert('RGBA')
        err = np.abs(np.asarray(check, np.int32)[..., :3] - np.asarray(small, np.int32)[..., :3]).mean()
        assert check.size == small.size and err < 12, (name, err)
        new[name] = data
        print('%s: %dx%d -> %dx%d, %d -> %d bytes (mean error %.1f)' % (name, w, h, w // scale, h // scale, len(d), len(data), err))
    vol = build.write_vol(orig, new)
    _, _, check = build.read_vol(vol)
    want = {e['name']: new.get(e['name'].decode('latin-1'), e['data']) for e in ents}
    assert {e['name']: e['data'] for e in check} == want
    open(dst, 'wb').write(vol)
    print('wrote %s (%d bytes, was %d)' % (dst, len(vol), len(orig)))
    return vol

if __name__ == '__main__':
    main(*sys.argv[1:])
