# make_files.py: makes the patched files of SpongeBob SquigglePants+ (the SquigglePants folder) from your own copy
# of the game: Boot.vol, menus.vol, Microgames.vol and Game305.vol in the your-game-files folder.
#   python3 make_files.py
import hashlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
GAME = os.path.join(ROOT, 'your-game-files')
# the US disc's (SS8E78) files: size and SHA-1
FILES = {
    'Boot.vol': (6481039, 'dc3afca31ae37432a887037b4b310020003078bd'),
    'menus.vol': (25933145, '48c145b92fe39c9d48554fd9a51788036288e663'),
    'Microgames.vol': (2280341, 'c6f36216f64b781665b8b6aa751f9f924346fd77'),
    'Game305.vol': (1440407, '2d6ee06b7c48099d0e9105a60be1cff8e3c3dd2c'),
}


def check():
    ok = True
    for name, (size, sha1) in FILES.items():
        path = os.path.join(GAME, name)
        if not os.path.exists(path):
            print('MISSING: %s is not in the your-game-files folder.' % name)
            ok = False
            continue
        data = open(path, 'rb').read()
        if len(data) != size or hashlib.sha1(data).hexdigest() != sha1:
            print('WRONG FILE: %s is not the US version\'s (SS8E78), or it has been changed.' % name)
            ok = False
        else:
            print('ok: %s' % name)
    return ok


def main():
    print('SpongeBob SquigglePants+: making the patched files\n')
    try:
        import numpy  # noqa: F401
        import PIL  # noqa: F401
    except ImportError:
        print('This needs the Python packages Pillow and NumPy. Install them with:\n'
              '    python3 -m pip install pillow numpy')
        return 1
    if not check():
        print('\nCopy the four files from your game into the your-game-files folder (see README.txt), then try '
              'again.')
        return 1
    sys.path.insert(0, HERE)
    import build
    print()
    build.main(os.path.join(GAME, 'Boot.vol'), os.path.join(HERE, 'titles.json'), ROOT,
               os.path.join(GAME, 'menus.vol'), code=False)
    out = os.path.join(ROOT, 'SquigglePants')
    print('\nDone! The SquigglePants folder is ready:')
    for f in sorted(os.listdir(out)):
        print('    SquigglePants/%s' % f)
    print('Now copy the riivolution and SquigglePants folders to your SD card (see README.txt).')
    return 0


if __name__ == '__main__':
    sys.exit(main())
