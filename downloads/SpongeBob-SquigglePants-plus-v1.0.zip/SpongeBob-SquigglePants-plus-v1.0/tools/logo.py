# Adds a "+" to the title-screen logos (menus.vol temp_titlecard*.image, one for each language: WIMGs in CMPR with an
# I4 alpha layer). The US logo is replaced whole by the high-quality SpongeBob SquigglePants+ logo (CARDS, below).
#   python3 logo.py <temp_titlecard*.image> <out.image> [preview.png]   (the logo's name says which language)
# Only the 8x8 tiles the "+" touches are re-encoded; every other tile keeps its original bytes.
import os
import struct
import sys

from PIL import Image, ImageChops, ImageDraw, ImageFilter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # wiivol.py, next to this file
import wiivol  # noqa: E402

# ---------------------------------------------------------------- WIMG tile streams

def read_stream(d, off, n, bs=32):
    hsz = struct.unpack('>I', d[off:off + 4])[0]
    p, tiles = off + hsz, []
    for b in d[off + 4:off + hsz]:
        if len(tiles) >= n:
            break
        if b & 0x80:
            for _ in range(b & 0x7F):
                tiles.append(d[p:p + bs]); p += bs
        elif b:
            tiles.extend([d[p:p + bs]] * b); p += bs
    return tiles

def write_stream(tiles):
    """Run table: 0x80 | n = n stored tiles follow; n (1..127) = one stored tile repeated n times."""
    ctl, data, i = bytearray(), bytearray(), 0
    while i < len(tiles):
        j = i
        while j < len(tiles) and tiles[j] == tiles[i] and j - i < 127:
            j += 1
        if j - i >= 2:
            ctl.append(j - i); data += tiles[i]; i = j
            continue
        j = i
        while j < len(tiles) and j - i < 127 and not (j + 1 < len(tiles) and tiles[j + 1] == tiles[j]):
            j += 1
        j = max(j, i + 1)
        ctl.append(0x80 | (j - i))
        for t in tiles[i:j]:
            data += t
        i = j
    while (4 + len(ctl)) % 4:
        ctl.append(0)
    return struct.pack('>I', 4 + len(ctl)) + bytes(ctl) + bytes(data)

# ---------------------------------------------------------------- encoders

def rgb565(c):
    return ((c[0] >> 3) << 11) | ((c[1] >> 2) << 5) | (c[2] >> 3)

def encode_cmpr_tile(px):
    """px: 8x8 rows of RGBA. Four 4x4 DXT1 blocks, always in 4-colour mode (alpha is a separate layer)."""
    out = bytearray()
    for bi in range(4):
        bx, by = (bi & 1) * 4, (bi >> 1) * 4
        blk = [px[by + y][bx + x] for y in range(4) for x in range(4)]
        pts = [p[:3] for p in blk if p[3] > 0] or [p[:3] for p in blk]
        best, a, b = -1, pts[0], pts[0]
        for p in pts:
            for q in pts:
                dist = sum((x - y) ** 2 for x, y in zip(p, q))
                if dist > best:
                    best, a, b = dist, p, q
        c0, c1 = rgb565(a), rgb565(b)
        if c0 < c1:
            c0, c1 = c1, c0
        pal = [wiivol.rgb565(c0)[:3], wiivol.rgb565(c1)[:3]]
        if c0 > c1:
            pal += [tuple((2 * x + y) // 3 for x, y in zip(pal[0], pal[1])),
                    tuple((x + 2 * y) // 3 for x, y in zip(pal[0], pal[1]))]
        idx = 0
        for i, p in enumerate(blk):
            k = min(range(len(pal)), key=lambda j: sum((x - y) ** 2 for x, y in zip(p[:3], pal[j])))
            idx |= k << (30 - 2 * i)
        out += struct.pack('>HHI', c0, c1, idx)
    return bytes(out)

def encode_i4_tile(alpha):
    """alpha: 8x8 rows of 0..255."""
    out = bytearray()
    for y in range(8):
        for x in range(0, 8, 2):
            out.append(((alpha[y][x] + 8) // 17) << 4 | ((alpha[y][x + 1] + 8) // 17))
    return bytes(out)

def bleed(img, rounds=8):
    """Spreads the edge colours into the fully clear pixels, so filtering at the edges never pulls in black."""
    rgb, a = img.convert('RGB'), img.getchannel('A')
    known = a.point(lambda v: 255 if v else 0)
    for _ in range(rounds):
        # average of the known neighbours: blur colour and mask together, then divide
        num = Image.composite(rgb, Image.new('RGB', rgb.size), known).filter(ImageFilter.BoxBlur(1))
        den = known.filter(ImageFilter.BoxBlur(1))
        n, d = num.load(), den.load()
        out = rgb.copy(); o = out.load(); k = known.load()
        for y in range(rgb.height):
            for x in range(rgb.width):
                if not k[x, y] and d[x, y]:
                    o[x, y] = tuple(min(255, c * 255 // d[x, y]) for c in n[x, y])
        known = den.point(lambda v: 255 if v else 0)
        rgb = out
    rgb.putalpha(a)
    return rgb

def replace_card(src, dst, card_png):
    """Swaps the whole logo for a ready-made one (the high-quality logo with its "+", already placed on a card the
    size of the original): every tile is re-encoded."""
    d = open(src, 'rb').read()
    assert d[:4] == b'WIMG' and d[5] == 14 and d[6] == 0
    w, h = struct.unpack('>HH', d[8:12])
    card = Image.open(card_png).convert('RGBA')
    assert card.size == (w, h), 'the card is %dx%d, the logo %dx%d' % (card.size + (w, h))
    tx, ty = (w + 7) // 8, (h + 7) // 8
    full = Image.new('RGBA', (tx * 8, ty * 8))
    full.paste(card, (0, 0))
    full = bleed(full)
    px = full.load()
    ctiles, atiles = [], []
    for j in range(ty):
        for i in range(tx):
            rows = [[px[i * 8 + x, j * 8 + y] for x in range(8)] for y in range(8)]
            ctiles.append(encode_cmpr_tile(rows))
            atiles.append(encode_i4_tile([[p[3] for p in r] for r in rows]))
    s1 = write_stream(ctiles)
    a_off = (0x20 + len(s1) + 31) // 32 * 32
    body = bytearray(d[:0x20])
    struct.pack_into('>II', body, 16, 0x20, a_off)
    body += s1
    body += b'\0' * (a_off - len(body))
    body += write_stream(atiles)
    open(dst, 'wb').write(bytes(body))
    check = wiivol.wimg(bytes(body)).convert('RGBA')
    assert check.size == (w, h)
    diff = ImageChops.difference(check.getchannel('A'), card.getchannel('A')).getextrema()[1]
    assert diff <= 9, 'alpha off by %d' % diff
    print('ok: %d bytes (was %d); new logo from %s' % (len(body), len(d), os.path.basename(card_png)))

# ---------------------------------------------------------------- the plus

FILL_TOP, FILL_BOTTOM = (255, 226, 40), (255, 166, 20)
OUTLINE = (20, 16, 46)
GLOW = (36, 42, 110)      # the soft dark edge around the letters
SWATCH = (52, 142, 196)   # the blue paint behind them


# where the "+" goes on each language's logo, just after the last word and raised a little, and its size
PLACES = {
    'temp_titlecard.image': (722, 240, 1.0),      # US: SpongeBob SquigglePants
    'temp_titlecard_pal.image': (706, 236, 1.0),  # UK: SpongeBob SquarePants SquigglePants
    'temp_titlecard_fr.image': (763, 282, 0.9),   # Bob l'Eponge : La Grande Art-venture
    'temp_titlecard_ger.image': (692, 250, 0.85),  # SpongeBob Schwammkopf: verflixt und zugemalt
    'temp_titlecard_ita.image': (673, 243, 0.9),  # SpongeBob: Il Grande Creatore
    'temp_titlecard_nl.image': (666, 296, 0.9),   # SpongeBob SquarePants: De onnozele Krabbelaar
    'temp_titlecard_spa.image': (675, 282, 0.9),  # Bob Esponja El Garabato
}

# logos replaced whole by a finished picture next to this file (854x481, the size and place of the original): the
# US one is the high-quality SpongeBob SquigglePants+ logo
CARDS = {'temp_titlecard.image': 'logo-card-us.png'}

def add_plus(img, cx=722, cy=240, size=1.0, style=None):
    """The logo with a "+" after its last word, raised a little, on a dab of the blue swatch. Returns the new
    image and the box that changed."""
    w, h = img.size
    arm, thick = 25 * size, 18 * size
    style = style or {}
    # a few overlapping strokes, joined to the swatch on the left, like the rest of the paint
    dab = Image.new('L', (w, h), 0)
    dd = ImageDraw.Draw(dab)
    for x0, y0, x1, y1 in ((-70, -34, 34, 30), (-40, -42, 40, 18), (-30, -10, 44, 40), (-76, 4, 16, 50)):
        x0, y0, x1, y1 = cx + x0 * size, cy + y0 * size, cx + x1 * size, cy + y1 * size
        dd.ellipse((x0, y0, x1, y1), fill=255)
    if style.get('rough'):  # a brushed edge: the dab's border broken up by noise
        import numpy as np
        rng = np.random.default_rng(1)
        noise = Image.fromarray((rng.random((h // 24 + 1, w // 24 + 1)) * 255).astype('uint8')).resize((w, h), Image.BICUBIC)
        soft = dab.filter(ImageFilter.GaussianBlur(8 * size))
        dab = Image.fromarray(((np.asarray(soft, float) + (np.asarray(noise, float) - 128) * 0.5) > 128).astype('uint8') * 255)
    dab = dab.filter(ImageFilter.GaussianBlur(1.5 * size))
    # the dab is the swatch's own blue, from just left of the "+" (the logos' blues differ a little)
    r, g, b, a = img.getpixel((int(cx - 50 * size), int(cy + 30 * size)))
    swatch = (r, g, b) if a > 200 and b > r + 60 else SWATCH
    swatch = style.get('swatch', swatch)
    out = Image.new('RGBA', (w, h), swatch + (0,))
    out.putalpha(dab)
    out.alpha_composite(img)  # the dab goes behind the existing logo
    if style.get('dab_over_edge'):
        # and over the paint's own edge where they meet, so its lighter rim doesn't show as a line
        import numpy as np
        from scipy import ndimage
        o = np.asarray(out).copy()
        src = np.asarray(img)
        r, g, b = src[..., 0].astype(int), src[..., 1].astype(int), src[..., 2].astype(int)
        paint = (b > r + 60) & (g > 100)
        rim = ndimage.distance_transform_edt(src[..., 3] > 128) <= 8
        m = (np.asarray(dab) / 255.0) * (paint & rim)
        o[..., :3] = (o[..., :3] * (1 - m[..., None]) + np.array(swatch) * m[..., None]).round()
        out = Image.fromarray(o.astype('uint8'), 'RGBA')
    glow_a = plus_layer((w, h), cx, cy, arm=arm, thick=thick, outline=6 * size, k=size).getchannel('A')
    glow_a = glow_a.filter(ImageFilter.GaussianBlur(2 * size))
    glow = Image.new('RGBA', (w, h), style.get('glow', GLOW) + (0,))
    glow.putalpha(glow_a)
    out.alpha_composite(glow)
    out.alpha_composite(plus_layer((w, h), cx, cy, arm=arm, thick=thick, outline=style.get('outline', 3) * size, k=size,
                                   colours=style.get('colours')))
    return out, ImageChops.lighter(dab, glow_a).getbbox()

def plus_layer(size, cx, cy, arm, thick, outline, ss=4, k=1.0, colours=None):
    """An RGBA layer with a rounded "+" in the logo's lettering style, drawn at ss times and scaled down. k scales
    the shine's insets and softness with the "+"."""
    W, H = size[0] * ss, size[1] * ss
    def shape(grow):
        m = Image.new('L', (W, H), 0)
        dr = ImageDraw.Draw(m)
        t, a, r = (thick / 2 + grow) * ss, (arm + grow) * ss, (thick / 2 + grow) * ss * 0.6
        X, Y = cx * ss, cy * ss
        dr.rounded_rectangle((X - a, Y - t, X + a, Y + t), radius=r, fill=255)
        dr.rounded_rectangle((X - t, Y - a, X + t, Y + a), radius=r, fill=255)
        return m
    inner, outer = shape(0), shape(outline)
    fill_top, fill_bottom, outline_colour = colours or (FILL_TOP, FILL_BOTTOM, OUTLINE)
    grad = Image.new('RGB', (W, H))
    top, bot = (cy - arm) * ss, (cy + arm) * ss
    gd = ImageDraw.Draw(grad)
    for y in range(H):
        t = min(1, max(0, (y - top) / max(1, bot - top)))
        gd.line([(0, y), (W, y)], fill=tuple(int(a + (b - a) * t) for a, b in zip(fill_top, fill_bottom)))
    layer = Image.new('RGBA', (W, H), outline_colour + (0,))
    layer.putalpha(outer)
    fill = grad.convert('RGBA')
    fill.putalpha(inner)
    layer.alpha_composite(fill)
    # a soft light streak on the upper left, like the letters' shine
    shine = Image.new('L', (W, H), 0)
    sd = ImageDraw.Draw(shine)
    X, Y, t, a = cx * ss, cy * ss, thick / 2 * ss, arm * ss
    q = k * ss
    sd.rounded_rectangle((X - a + 4 * q, Y - t + 3 * q, X - t, Y - t + 7 * q), radius=2 * q, fill=120)
    sd.rounded_rectangle((X - t + 3 * q, Y - a + 4 * q, X - t + 7 * q, Y - t), radius=2 * q, fill=120)
    shine = shine.filter(ImageFilter.GaussianBlur(2 * q))
    shine = Image.composite(shine, Image.new('L', (W, H), 0), inner)
    white = Image.new('RGBA', (W, H), (255, 255, 230, 0))
    white.putalpha(shine)
    layer.alpha_composite(white)
    return layer.resize(size, Image.LANCZOS)

def main(src, dst, preview=None, name='temp_titlecard.image'):
    d = open(src, 'rb').read()
    assert d[:4] == b'WIMG' and d[5] == 14 and d[6] == 0
    w, h = struct.unpack('>HH', d[8:12])
    o1, o2 = struct.unpack('>II', d[16:24])
    tx, ty = (w + 7) // 8, (h + 7) // 8
    n = tx * ty
    ctiles, atiles = read_stream(d, o1, n), read_stream(d, o2, n)
    img = wiivol.wimg(d).convert('RGBA')

    out, box = add_plus(img, *PLACES[name])

    px = out.load()
    for ty_ in range(box[1] // 8, (box[3] + 7) // 8):
        for tx_ in range(box[0] // 8, (box[2] + 7) // 8):
            rows = [[px[min(w - 1, tx_ * 8 + x), min(h - 1, ty_ * 8 + y)] for x in range(8)] for y in range(8)]
            ctiles[ty_ * tx + tx_] = encode_cmpr_tile(rows)
            atiles[ty_ * tx + tx_] = encode_i4_tile([[p[3] for p in r] for r in rows])

    s1 = write_stream(ctiles)
    a_off = 0x20 + len(s1)
    a_off = (a_off + 31) // 32 * 32
    body = bytearray(d[:0x20])
    struct.pack_into('>II', body, 16, 0x20, a_off)
    body += s1
    body += b'\0' * (a_off - len(body))
    body += write_stream(atiles)
    open(dst, 'wb').write(bytes(body))

    # check: decodes with the reference decoder, unchanged outside the "+" tiles
    check = wiivol.wimg(bytes(body)).convert('RGBA')
    x0, y0 = box[0] // 8 * 8, box[1] // 8 * 8
    x1, y1 = (box[2] + 7) // 8 * 8, (box[3] + 7) // 8 * 8
    mask = Image.new('L', (w, h), 255)
    ImageDraw.Draw(mask).rectangle((x0, y0, x1 - 1, y1 - 1), fill=0)
    blank = Image.new('RGBA', (w, h))
    a = Image.composite(img, blank, mask).tobytes()
    b = Image.composite(check, blank, mask).tobytes()
    assert a == b, 'tiles outside the "+" changed'
    print('ok: %d bytes (was %d); re-encoded tiles in %s' % (len(body), len(d), (x0, y0, x1, y1)))
    if preview:
        bg = Image.new('RGBA', (w, h), (40, 40, 40, 255))
        bg.alpha_composite(check)
        bg.crop((100, 60, 800, 410)).save(preview)

def clean_edges(img):
    """Cleans a cut-out whose background was removed by hand: all-or-nothing alpha, with a light fringe of the old
    white background along the edge. Whitish pixels joined to the outside go; light pixels near the edge take the
    colour of the paint just inside; and the edge gets smooth, anti-aliased alpha."""
    import numpy as np
    from scipy import ndimage
    a = np.asarray(img.convert('RGBA')).astype(float)
    rgb, inside = a[..., :3], a[..., 3] > 0
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    # the paint is a strong blue (red well below blue); the fringe is white or a pale blend of white and blue
    whitish = inside & (r > 120) & (b - r < 90) & (g > 150)
    pale = inside & (r > 75) & (b > 150) & (g > 140)
    # whitish pixels reachable from the outside through other whitish pixels
    outside = ~inside
    labels, _ = ndimage.label(whitish | outside)
    joined = np.unique(labels[outside])
    fringe = whitish & np.isin(labels, joined[joined > 0])
    keep = inside & ~fringe
    # pale pixels within 3 pixels of the edge are blends with the old background: recoloured from inside
    depth = ndimage.distance_transform_edt(keep)
    clean = keep & ~(pale & (depth <= 3))
    # stray specks of the old background on the outline: small bright blobs with blue paint all round them (the
    # light flecks further in are the paint's own texture)
    bright = keep & (r - ndimage.median_filter(r, size=15) > 30) & (depth <= 6)
    paint = (b > r + 60) & (g > 100)
    labels, n = ndimage.label(bright)
    specks = 0
    for i, sl in enumerate(ndimage.find_objects(labels), 1):
        blob = labels[sl] == i
        if blob.sum() > 120:
            continue
        sl2 = tuple(slice(max(0, x.start - 2), x.stop + 2) for x in sl)
        blob2 = labels[sl2] == i
        ring = ndimage.binary_dilation(blob2, iterations=2) & ~blob2
        if (paint[sl2][ring] | ~inside[sl2][ring]).mean() > 0.85:
            clean[sl2] &= ~blob2
            specks += 1
    _, (iy, ix) = ndimage.distance_transform_edt(~clean, return_indices=True)
    rgb = rgb[iy, ix]  # every other pixel takes its nearest clean pixel's colour
    # smooth the jagged cut: a slightly opened mask, blurred into an anti-aliased edge
    keep = ndimage.binary_opening(keep, iterations=1)
    soft = ndimage.gaussian_filter(keep.astype(float), 0.8)
    alpha = np.clip((soft - 0.5) * 2.2 + 0.5, 0, 1) * 255
    out = np.dstack([rgb, alpha]).round().astype('uint8')
    print('edges: %d fringe pixels removed, %d edge pixels recoloured, %d specks' % (fringe.sum(), (keep & ~clean).sum(), specks))
    return Image.fromarray(out, 'RGBA')

def big_logo(src, dst):
    """A "+" on a large picture of the US logo (not for the game): the same "+", sized to its letters, with the
    canvas widened to fit it."""
    img = clean_edges(Image.open(src).convert('RGBA'))
    size = 3.2  # its letters are about 3.2 times the game's
    pad = 150
    wide = Image.new('RGBA', (img.width + pad, img.height), (0, 0, 0, 0))
    wide.paste(img, (0, 0))
    # this art's letters are brighter, with a softer, bluer edge, on brushed paint
    style = {'rough': True, 'dab_over_edge': True, 'swatch': (0, 151, 205), 'glow': (30, 44, 140), 'outline': 1.6,
             'colours': ((255, 238, 20), (255, 176, 28), (28, 34, 100))}
    out, _ = add_plus(wide, cx=1870, cy=495, size=size, style=style)
    out = out.crop(out.getbbox())
    out.save(dst)
    print('wrote %s (%dx%d)' % (dst, out.width, out.height))

if __name__ == '__main__':
    if sys.argv[1] == '--big':
        big_logo(sys.argv[2], sys.argv[3])
        sys.exit()
    main(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None, os.path.basename(sys.argv[1]))
