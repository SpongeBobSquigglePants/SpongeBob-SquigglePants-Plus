# Italic letters for the game's fonts. The fonts have no italic style, so each font gets slanted copies of the
# letters a title needs, as characters of the Unicode private use area (U+E000 on), which the title's text is then
# written with: the game draws them like any other letter. The slant is a shear about the baseline, so the letters
# keep their places and widths.
#
# FONT files: u16 glyph count @0x08, u8 log2 bucket count @0x0C; u32 bucket table @0x10 (u16 first glyph of each
# bucket, and one past the last), glyph table @0x18 (20 bytes: u32 code point, u16 w, h, s16 left, right, drop,
# unknown, u32 bitmap offset), outline section @0x28 (a u32, then the outline table @0x2C: 12 bytes, u16 w, h,
# s16 x, y, u32 bitmap offset). Bitmaps are 4 bits a pixel, high nibble first, rows padded to a byte, from the end
# of the outline table to the end of the file; an empty glyph has offset 0. The game finds a code point in the
# bucket its hash (glyph_hash, 0x801642a4) gives.
#   python3 italic.py <in.font> <out.font> <text>   (adds italic copies of the text's letters; prints the mapping)
import struct
import sys

import numpy as np

SLANT = 0.2   # horizontal shift per pixel of height
FIRST = 0xE000

def glyph_hash(cp):
    """The game's hash of a code point (Bob Jenkins' mix of a single word, as 0x801642a4 computes it)."""
    m = 0xFFFFFFFF
    b = (0x9E3779B9 - 4) & m
    a = (cp - 4) & m
    b = (b - a) & m
    c = (4 - a) & m
    b ^= (a << 8) & m
    c = (c - b) & m
    a = (a - b) & m
    c ^= b >> 13
    a = (a - c) & m
    b = (b - c) & m
    a ^= c >> 12
    b = (b - a) & m
    c = (c - a) & m
    b ^= (a << 16) & m
    c = (c - b) & m
    a = (a - b) & m
    c ^= b >> 5
    a = (a - c) & m
    b = (b - c) & m
    a ^= c >> 3
    b = (b - a) & m
    c = (c - a) & m
    b ^= (a << 10) & m
    c = (c - b) & m
    c ^= b >> 15
    return c

def read_bitmap(d, off, w, h):
    stride = (w + 1) // 2
    a = np.zeros((h, w), np.float64)
    for y in range(h):
        row = d[off + y * stride:off + (y + 1) * stride]
        for x in range(w):
            b = row[x // 2]
            a[y, x] = ((b & 15) if x & 1 else (b >> 4)) / 15.0
    return a

def write_bitmap(a):
    h, w = a.shape
    q = np.clip(np.rint(a * 15), 0, 15).astype(np.uint8)
    out = bytearray()
    for y in range(h):
        row = list(q[y]) + ([0] if w & 1 else [])
        out += bytes((row[i] << 4) | row[i + 1] for i in range(0, len(row), 2))
    return bytes(out)

def shear(a, top):
    """Slants a bitmap whose top row is `top` pixels below the baseline (negative: above). Returns the new bitmap
    and how far its left edge moved."""
    h, w = a.shape
    shifts = [-SLANT * (top + r + 0.5) for r in range(h)]  # y up is the shear's direction
    lo, hi = int(np.floor(min(shifts))), int(np.ceil(max(shifts)))
    out = np.zeros((h, w + hi - lo + 1))  # a column more, for the fractions
    for r in range(h):
        s = shifts[r] - lo
        i, f = int(np.floor(s)), s - np.floor(s)
        out[r, i:i + w] += a[r] * (1 - f)
        out[r, i + 1:i + 1 + w] += a[r] * f
    while out.shape[1] > w and not out[:, -1].any():
        out = out[:, :-1]
    return np.clip(out, 0, 1), lo

class Font:
    def __init__(self, d):
        self.d = d
        u32 = lambda o: struct.unpack('>I', d[o:o + 4])[0]
        n, = struct.unpack('>H', d[8:10])
        self.nbuckets = 1 << d[0x0C]
        self.bucket_table, self.glyph_table = u32(0x10), u32(0x18)
        self.outline_section, outline_table = u32(0x28), u32(0x2C)
        assert outline_table == self.outline_section + 4
        self.glyphs = [list(struct.unpack('>IHHhhhhI', d[self.glyph_table + i * 20:self.glyph_table + i * 20 + 20]))
                       for i in range(n)]
        self.outlines = [list(struct.unpack('>HHhhI', d[outline_table + i * 12:outline_table + i * 12 + 12]))
                         for i in range(n)]
        self.bitmaps_at = outline_table + 12 * n
        starts = struct.unpack('>%dH' % (self.nbuckets + 1), d[self.bucket_table:self.bucket_table + 2 * (self.nbuckets + 1)])
        for b in range(self.nbuckets):
            for i in range(starts[b], starts[b + 1]):
                assert glyph_hash(self.glyphs[i][0]) & (self.nbuckets - 1) == b, 'hash does not match the file'
        self.new = []  # (glyph entry, outline entry, fill bitmap, outline bitmap)

    def code_points(self):
        return {g[0] for g in self.glyphs}

    def add_italic(self, cp, new_cp):
        i = [g[0] for g in self.glyphs].index(cp)
        c, w, h, left, right, drop, unk, off = self.glyphs[i]
        ow, oh, ox, oy, ooff = self.outlines[i]
        top = -(h - drop)
        if w and h:
            fill, lo = shear(read_bitmap(self.d, off, w, h), top)
            outline, olo = shear(read_bitmap(self.d, ooff, ow, oh), top + oy) if ow and oh else (None, 0)
        else:
            fill, lo, outline, olo = None, 0, None, 0
        nw = fill.shape[1] if fill is not None else 0
        hi = nw - w + lo if fill is not None else 0
        g = [new_cp, nw, h, left + lo, right - hi, drop, unk, 0]
        o = [outline.shape[1] if outline is not None else ow, oh, ox + olo - lo, oy, 0]
        self.new.append((g, o, fill, outline))

    def build(self):
        glyphs = [list(g) for g in self.glyphs] + [n[0] for n in self.new]
        outlines = [list(o) for o in self.outlines] + [n[1] for n in self.new]
        n = len(glyphs)
        delta = 32 * len(self.new)  # the tables grow by 20 + 12 bytes a glyph
        bitmaps = bytearray(self.d[self.bitmaps_at:])
        base = self.bitmaps_at + delta
        for g, o in zip(glyphs, outlines):
            if g[7]: g[7] += delta
            if o[4]: o[4] += delta
        for k, (_, _, fill, outline) in enumerate(self.new):
            g, o = glyphs[len(self.glyphs) + k], outlines[len(self.glyphs) + k]
            if fill is not None:
                g[7] = base + len(bitmaps)
                bitmaps += write_bitmap(fill)
            if outline is not None:
                o[4] = base + len(bitmaps)
                bitmaps += write_bitmap(outline)
        # each bucket's glyphs together, in their old order, the new ones after
        order = sorted(range(n), key=lambda i: (glyph_hash(glyphs[i][0]) & (self.nbuckets - 1), i))
        starts, b = [], 0
        for bucket in range(self.nbuckets + 1):
            while b < n and glyph_hash(glyphs[order[b]][0]) & (self.nbuckets - 1) < bucket:
                b += 1
            starts.append(b)
        out = bytearray(self.d[:self.glyph_table])
        struct.pack_into('>H', out, 8, n)
        struct.pack_into('>%dH' % (self.nbuckets + 1), out, self.bucket_table, *starts)
        for i in order:
            out += struct.pack('>IHHhhhhI', *glyphs[i])
        section = len(out)
        out += self.d[self.outline_section:self.outline_section + 4]
        for i in order:
            out += struct.pack('>HHhhI', *outlines[i])
        assert len(out) == base
        out += bitmaps
        struct.pack_into('>I', out, 0x28, section)
        struct.pack_into('>I', out, 0x2C, section + 4)
        return bytes(out)

def mapping(texts):
    """The private-use character for each letter in the texts, the same for every font."""
    chars = sorted({ch for t in texts for ch in t})
    return {ch: chr(FIRST + i) for i, ch in enumerate(chars)}

def italicise(font_data, chars):
    """The font with italic copies of `chars` (a mapping from mapping()); letters it doesn't have are skipped."""
    f = Font(font_data)
    have = f.code_points()
    missing = [ch for ch in chars if ord(ch) not in have]
    for ch, pua in chars.items():
        if ord(ch) in have:
            f.add_italic(ord(ch), ord(pua))
    return f.build(), missing

if __name__ == '__main__':
    m = mapping([sys.argv[3]])
    out, missing = italicise(open(sys.argv[1], 'rb').read(), m)
    open(sys.argv[2], 'wb').write(out)
    print('added %d italic letters%s' % (len(m) - len(missing), ', missing %r' % missing if missing else ''))
