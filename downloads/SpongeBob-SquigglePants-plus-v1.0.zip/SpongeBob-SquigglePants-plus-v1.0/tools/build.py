# Builds the SquigglePants Riivolution patch from a copy of the game's Boot.vol (US release, SS8E78).
#   python3 build.py <Boot.vol> <titles.json> <out dir> [menus.vol]
# Writes <out>/riivolution/SquigglePants.xml and <out>/SquigglePants/Boot.vol, and with menus.vol, the title-screen
# logos with their "+" in <out>/SquigglePants/menus.vol (see logo.py).
import json
import os
import re
import struct
import sys

# ---------------------------------------------------------------- DVOL archives

def read_vol(d):
    assert d[:4] == b'DVOL'
    n, tab = struct.unpack('>II', d[0x14:0x1C])
    ents = []
    for i in range(n):
        h, no, off, flag, size = struct.unpack('>5I', d[tab + i * 20:tab + i * 20 + 20])
        name = d[no:d.index(b'\0', no)]
        ents.append({'hash': h, 'name': name, 'flag': flag, 'data': d[off:off + size], 'off': off, 'noff': no})
    return n, tab, ents

def write_vol(orig, files):
    """Rebuilds the archive with the same header, entry order and layout rules (data 32-byte aligned in entry
    order, names at the end), replacing the data of the files named in `files`."""
    n, tab, ents = read_vol(orig)
    assert [e['off'] for e in ents] == sorted(e['off'] for e in ents), 'data not in entry order'
    first = min(e['off'] for e in ents)
    out = bytearray(orig[:first])  # header, group table and entry table (entries are rewritten below)
    for e in ents:
        e['data'] = files.get(e['name'].decode('latin-1'), e['data'])
        while len(out) % 32:
            out.append(0)
        e['newoff'] = len(out)
        out += e['data']
    # names, in their original order and spacing
    nstart = min(e['noff'] for e in ents)
    names_blob = orig[nstart:]
    base = len(out)
    out += names_blob
    for i, e in enumerate(ents):
        struct.pack_into('>5I', out, tab + i * 20, e['hash'], base + e['noff'] - nstart, e['newoff'], e['flag'],
                         len(e['data']))
    struct.pack_into('>I', out, 0x10, len(out))
    return bytes(out)

def name_hash(name):
    """The game's file and text-key hash: Bob Jenkins' lookup2 (initval 0) over the lowercased name."""
    def mix(a, b, c):
        M = 0xFFFFFFFF
        a = (a - b - c) & M; a ^= c >> 13
        b = (b - c - a) & M; b ^= (a << 8) & M
        c = (c - a - b) & M; c ^= b >> 13
        a = (a - b - c) & M; a ^= c >> 12
        b = (b - c - a) & M; b ^= (a << 16) & M
        c = (c - a - b) & M; c ^= b >> 5
        a = (a - b - c) & M; a ^= c >> 3
        b = (b - c - a) & M; b ^= (a << 10) & M
        c = (c - a - b) & M; c ^= b >> 15
        return a, b, c
    k = name.lower().encode('latin-1')
    a = b = 0x9E3779B9
    c = 0
    i, n = 0, len(k)
    while n - i >= 12:
        a = (a + int.from_bytes(k[i:i + 4], 'little')) & 0xFFFFFFFF
        b = (b + int.from_bytes(k[i + 4:i + 8], 'little')) & 0xFFFFFFFF
        c = (c + int.from_bytes(k[i + 8:i + 12], 'little')) & 0xFFFFFFFF
        a, b, c = mix(a, b, c)
        i += 12
    c = (c + n) & 0xFFFFFFFF
    rest = k[i:]
    for j, ch in enumerate(rest):
        if j < 4:
            a = (a + (ch << (8 * j))) & 0xFFFFFFFF
        elif j < 8:
            b = (b + (ch << (8 * (j - 4)))) & 0xFFFFFFFF
        else:
            c = (c + (ch << (8 * (j - 7)))) & 0xFFFFFFFF
    return mix(a, b, c)[2]

def add_file(orig, name, data):
    """A copy of a DVOL with one more file. Entries are kept in hash groups (8 in Boot.vol, 64 in menus.vol) by
    the low bits of the name's hash; the u16 group ends from 0x1E up to the entry table are updated."""
    n, tab, ents = read_vol(orig)
    slots = (tab - 0x1E) // 2
    allends = list(struct.unpack('>%dH' % slots, orig[0x1E:tab]))
    groups = next(g for g in (8, 16, 32, 64, 128) if g <= slots and allends[g - 1] == n)
    ends = allends[:groups]
    h = name_hash(name)
    g = h % groups
    new = {'hash': h, 'name': name.encode('latin-1'), 'flag': 0, 'data': data}
    ents.insert(ends[g], new)
    for k in range(g, groups):
        ends[k] += 1
    # names: the originals in order, then the new one
    names = bytearray()
    for e in sorted((e for e in ents if e is not new), key=lambda e: e['noff']):
        e['nrel'] = len(names); names += e['name'] + b'\0'
    new['nrel'] = len(names); names += new['name'] + b'\0'
    out = bytearray(orig[:tab])
    struct.pack_into('>I', out, 0x14, n + 1)
    struct.pack_into('>%dH' % groups, out, 0x1E, *ends)
    out += b'\0' * (20 * (n + 1))
    for e in sorted(ents, key=lambda e: e.get('off', 1 << 40)):
        while len(out) % 32:
            out.append(0)
        e['newoff'] = len(out)
        out += e['data']
    base = len(out)
    out += names
    for i, e in enumerate(ents):
        struct.pack_into('>5I', out, tab + i * 20, e['hash'], base + e['nrel'], e['newoff'], e['flag'], len(e['data']))
    struct.pack_into('>I', out, 0x10, len(out))
    return bytes(out)

# ---------------------------------------------------------------- TXTS text tables

def read_txts(d):
    nlang, = struct.unpack('>H', d[0x0A:0x0C])
    n, tab = struct.unpack('>II', d[0x14:0x1C])
    rows = []
    for i in range(n):
        e = list(struct.unpack('>%dI' % (nlang + 1), d[tab + i * (4 + 4 * nlang):tab + (i + 1) * (4 + 4 * nlang)]))
        rows.append(e)
    return nlang, n, tab, rows

def get_str(d, o):
    return d[o:d.index(b'\0', o)].decode('utf-8')

def set_strings(d, changes):
    """changes: {(row, lang): new text}. The new strings are added after the existing ones (the format has no
    size field and its strings run to the end of the file), and their entries point at them."""
    nlang, n, tab, rows = read_txts(d)
    out = bytearray(d)
    for (r, lang), text in changes.items():
        rows[r][1 + lang] = len(out)
        out += text.encode('utf-8') + b'\0'
    for i, e in enumerate(rows):
        struct.pack_into('>%dI' % (nlang + 1), out, tab + i * (4 + 4 * nlang), *e)
    return bytes(out)

# ---------------------------------------------------------------- the edits

EXTRA_TITLES = {}
# other on-screen text (English), by file
UI_FIXES = {'UiText.text': {
    'Press        To Begin': 'Press        to Begin',
    'Select A World': 'Select a World',
    'Select A Minigame': 'Select a Minigame',
    'Select A Movie': 'Select a Movie',
    'Select A Nanogame': 'Select a Nanogame',
    ('Avast there me hearties! Ye kin press yer stylus against the uDraw GameTablet hard or soft. I like to press '
     'softly sometimes\u2026 An other times, I push hard an give the game no quarter! Arrr!'):
    ('Avast there me hearties! Ye kin press yer stylus against the uDraw GameTablet hard or soft. I like to press '
     'softly sometimes... An other times, I push hard an give the game no quarter! Arrr!'),
}, 'WiiText.text': {
    ('There is no Save Data for SpongeBob Squigglepants...\r\rCreating Save Data will allow you to save your '
     'progress.'):
    'There is no save data for SpongeBob SquigglePants...\r\rCreating save data will allow you to save your progress.',
    'Create Save Data': 'Create save data',
    'Continue Without Saving': 'Continue without saving',
    'Please Insert the \rSpongeBob Squigglepants disc.': 'Please insert the \rSpongeBob SquigglePants disc.',
    'Creating Save Data.  Do not touch the Power Button or RESET.':
    'Creating save data. Do not touch the power button or RESET.',
    'Checking for Save Data.  Do not touch the Power Button or RESET.':
    'Checking for save data. Do not touch the power button or RESET.',
    'Deleting Save Data.  Do not touch the Power Button or RESET.':
    'Deleting save data. Do not touch the power button or RESET.',
    'Saving in progress.  Please do not touch the Power Button or RESET.':
    'Saving in progress. Please do not touch the power button or RESET.',
}, 'ArtStudio.text': {
    'Saving in progress.  Please do not touch the Power Button or RESET.':
    'Saving in progress. Please do not touch the power button or RESET.',
}}
# text replaced in every language: the controls word the IconBob games show under the uDraw icon before they start
# (their input, SLIDE, is the Nintendo 3DS circle pad; with the patch they are steered with the D-pad). Columns:
# English, French, German, Italian, Dutch, Spanish.
ALL_LANGUAGE_FIXES = {'Hints.text': {
    'SLIDE!': ['D-PAD!', 'CROIX \nDIRECTIONNELLE !', 'STEUERKREUZ!', 'CROCE \nDIREZIONALE!', 'BEDIENINGSKNOP!',
               '¡CRUCETA!'],
}}
WRITER = (b'<0>Writer<1>\r\nLuke Brookshier\r\n\r\n'
          b'<0>SpongeBob SquigglePants+<1>\r\nMitch "WubbzP" Bentz\r\n\r\n')
# The game's title, in italics wherever the game draws it, in each language (the French one with a straight
# apostrophe); see italic.py. Not in WiiText's 0xbc32fef9, the save's name in the Wii's own Data Management screen,
# which can't draw the italic letters.
TITLES = ['SpongeBob SquigglePants+', 'SpongeBob SquigglePants', "Bob l'Éponge : La Grande Art-venture",
          'SpongeBob Schwammkopf: verflixt und zugemalt', 'SpongeBob: Il Grande Creatore',
          'SpongeBob SquarePants: De onnozele Krabbelaar', 'Bob Esponja El Garabato']
NOT_ITALIC = {0xBC32FEF9}
ITALIC_FONTS = ['VAGRounded_29B.font', 'VAGRounded_50B.font']  # in Boot.vol: the Wii dialogs' and warnings' font
# menus.vol's, added to Boot.vol (which the game looks in first): the save dialogs' text and the credits' headings
ITALIC_FONTS_ADDED = ['VAGRounded_21B.font', 'Sponge36.font']

def italic_titles(s, chars):
    """s with every title in it written with italic letters."""
    s = s.replace("Bob l\u2019\u00c9ponge", "Bob l'\u00c9ponge")
    for t in TITLES:  # the longest first: SquigglePants+ before SquigglePants
        s = s.replace(t, ''.join(chars[c] for c in t))
    return s

COMPOSER = (b'<0>Audio Guy<1>\r\nJake Kaufman\r\n', b'<0>Composer<1>\r\nJake Kaufman\r\n')
DEVELOPED_BY = (b'<0>DEVELOPED BY<1>\r\nWAYFORWARD TECHNOLOGIES\r\n', b'<0>Developed by<1>\r\nWayForward Technologies\r\n')
AFTER = b'<0>Designer / Director<1>\r\nJames Montagna\r\n\r\n'

XML = '''<wiidisc version="1">
\t<id game="SS8E" />
\t<options>
\t\t<section name="SpongeBob SquigglePants Fixes">
\t\t\t<option name="100% Completion Fix" default="1">
\t\t\t\t<choice name="Enabled">
\t\t\t\t\t<patch id="completion" />
\t\t\t\t</choice>
\t\t\t</option>
\t\t\t<option name="Ending Credits Slowdown Fix" default="1">
\t\t\t\t<choice name="Enabled">
\t\t\t\t\t<patch id="cull" />
\t\t\t\t</choice>
\t\t\t</option>
\t\t\t<option name="Title and Credit Fixes" default="1">
\t\t\t\t<choice name="Enabled">
\t\t\t\t\t<patch id="text" />
\t\t\t\t</choice>
\t\t\t</option>
\t\t\t<option name="SpongeBob SquigglePants+ Logo" default="1">
\t\t\t\t<choice name="Enabled">
\t\t\t\t\t<patch id="logo" />
\t\t\t\t</choice>
\t\t\t</option>
\t\t\t<option name="IconBob in Replay" default="1">
\t\t\t\t<choice name="Enabled">
\t\t\t\t\t<patch id="replay" />
\t\t\t\t\t<patch id="extras" />
\t\t\t\t</choice>
\t\t\t</option>
\t\t\t<option name="Credits and Puzzle de Pants in Options" default="1">
\t\t\t\t<choice name="Enabled">
\t\t\t\t\t<patch id="options" />
\t\t\t\t\t<patch id="extras" />
\t\t\t\t</choice>
\t\t\t</option>
\t\t\t<option name="Dev Menu">
\t\t\t\t<choice name="Enabled">
\t\t\t\t\t<patch id="devmenu" />
\t\t\t\t</choice>
\t\t\t</option>
\t\t</section>
\t</options>
\t<!-- The save screen only gives its last point for a Nanogame Replay best above 100, while the 100% Complete
\t     reward (and the last Patchy movie) needs 100. This compares with 99 instead, so a best of 100 counts. -->
\t<patch id="completion">
\t\t<memory offset="0x8005C9D4" value="28040063" original="28040064" />
\t</patch>
\t<!-- The credits after PixelBob's ending (in the story, and Movies entry 7) are one text of a few thousand letters,
\t     all drawn every frame, and the game drops to a few frames a second: letters far off the screen are skipped
\t     (code/cull.c). -->
\t<patch id="cull">
@CULL@
\t</patch>
\t<!-- Corrected nanogame titles and menu text, and Luke Brookshier's writer credit from the Nintendo 3DS version. -->
\t<patch id="text">
\t\t<file disc="/Boot.vol" external="/SquigglePants/Boot.vol" />
\t</patch>
\t<!-- The title-screen logos with a "+": the high-quality SpongeBob SquigglePants+ logo in English (US), and a "+"
\t     after the last word in the other languages. -->
\t<patch id="logo">
\t\t<file disc="/menus.vol" external="/SquigglePants/menus.vol" />
\t</patch>
\t<!-- IconBob, the Nintendo 3DS world, whose seven nanogames are on the Wii disc, as the eighth Nanogame Replay
\t     section the game was made ready for, steered with the D-pad (code/replay.c, code/iconbob_save.c). Its records
\t     are kept in spare bits of the save slot. Game305.vol has Candid Krabs' big images shrunk, as at their 3DS
\t     size they don't fit in memory or in a texture (shrink.py). -->
\t<patch id="replay">
\t\t<file disc="/Game305.vol" external="/SquigglePants/Game305.vol" />
@REPLAY@
\t</patch>
\t<!-- SquigglePantsPlus.vol, a new disc file mounted at start-up, with IconBob's controls icon and the Options
\t     screen's Puzzle de Pants frame (code/mount.c). -->
\t<patch id="extras">
\t\t<file disc="/SquigglePantsPlus.vol" external="/SquigglePants/SquigglePantsPlus.vol" create="true" />
@EXTRAS@
\t</patch>
\t<!-- A Credits button on the Options screen for the game's scrolling credits, left in the game for the Dev Menu
\t     only, with a Back tab and scrolling by hand; once they have been watched to the end, a frame on the wall
\t     plays Puzzle de Pants, the cut nanogame (code/options.c). -->
\t<patch id="options">
@OPTIONS@
\t</patch>
\t<!-- Starts in the developers' Dev Menu left in the game, with its stripped navigation put back (code/devmenu.c):
\t     D-pad moves, A picks, B goes back. "Boot" starts the game as normal. -->
\t<patch id="devmenu">
@DEVMENU@
\t</patch>
</wiidisc>
'''

def patch_menus(menus_path, out_dir):
    import logo
    orig = open(menus_path, 'rb').read()
    assert write_vol(orig, {}) == orig, 'repacking the untouched menus.vol does not give the same bytes'
    _, _, ents = read_vol(orig)
    files = {e['name'].decode('latin-1'): e['data'] for e in ents}
    tmp_in, tmp_out = os.path.join(out_dir, '_tc_in'), os.path.join(out_dir, '_tc_out')
    new = {}
    for name in logo.PLACES:  # every language's logo
        open(tmp_in, 'wb').write(files[name])
        card = os.path.join(os.path.dirname(os.path.abspath(__file__)), logo.CARDS.get(name, ''))
        if name in logo.CARDS:  # a finished logo replaces the whole picture
            logo.replace_card(tmp_in, tmp_out, card)
        else:
            logo.main(tmp_in, tmp_out, name=name)
        new[name] = open(tmp_out, 'rb').read()
    os.remove(tmp_in); os.remove(tmp_out)
    vol = write_vol(orig, new)
    _, _, check = read_vol(vol)
    assert {e['name'].decode('latin-1'): e['data'] for e in check} == dict(files, **new)
    open(os.path.join(out_dir, 'SquigglePants', 'menus.vol'), 'wb').write(vol)
    print('logo: menus.vol written (%d bytes)' % len(vol))

def empty_vol():
    """A DVOL with no files, 8 hash groups (as Boot.vol)."""
    out = bytearray(0x30)
    out[0:4] = b'DVOL'
    struct.pack_into('>III', out, 4, 2, 3, 0x1C)
    struct.pack_into('>III', out, 0x10, 0x30, 0, 0x30)
    return bytes(out)

def puzzle_frame(menus):
    """The Puzzle de Pants frame for the Options screen, made like the Replay section frames (replay_frame_0N_a, 195x159:
    a picture in the bamboo frame, with a shadow): the game's own Remix thumbnail of it in the bamboo frame, on
    replay_frame_07_a's shadow."""
    import numpy as np
    from PIL import Image
    import shrink
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # wiivol.py, next to this file
    import wiivol
    img = lambda n: wiivol.wimg(menus[n]).convert('RGBA')
    out = img('replay_frame_07_a.image')
    inner = img('remix_game_095.image')
    inner.alpha_composite(img('replay_frame_bamboo.image'))
    out.paste(inner, (14, 14))  # where replay_frame_07_a has its bamboo frame
    data = shrink.encode(out, menus['replay_frame_07_a.image'], True, 1)
    data = data[:0x18] + b'\0' + data[0x19:]  # drawn at its own size
    check = np.asarray(wiivol.wimg(data).convert('RGBA'), np.int32)
    assert np.abs(check - np.asarray(out, np.int32)).mean() < 12
    return data

def make_extras(game_dir, out_dir):
    """SquigglePantsPlus.vol: new files the patch code mounts at start-up (a disc file of its own, so that no option
    needs another option's copy of a game archive): the controls icon of the IconBob games (the screen before them
    asks for DS_Mechanics_icon_SLIDE.anim, their input, SLIDE, being the Nintendo 3DS circle pad, which the Wii disc
    doesn't have; they get the PRESS one, as they're played with the D-pad) and the Options screen's Puzzle de Pants
    frame."""
    _, _, ents = read_vol(open(os.path.join(game_dir, 'Microgames.vol'), 'rb').read())
    micro = {e['name'].decode('latin-1'): e['data'] for e in ents}
    _, _, ents = read_vol(open(os.path.join(game_dir, 'menus.vol'), 'rb').read())
    menus = {e['name'].decode('latin-1'): e['data'] for e in ents}
    files = {'DS_Mechanics_icon_SLIDE.anim': micro['Mechanics_icon_PRESS.anim'],
             'options_frame_puzzle.image': puzzle_frame(menus)}
    vol = empty_vol()
    for name, data in files.items():
        vol = add_file(vol, name, data)
    _, _, check = read_vol(vol)
    assert {e['name'].decode('latin-1'): e['data'] for e in check} == files
    open(os.path.join(out_dir, 'SquigglePants', 'SquigglePantsPlus.vol'), 'wb').write(vol)
    print('extras: SquigglePantsPlus.vol written (%d bytes)' % len(vol))
    import shrink
    shrink.main(os.path.join(game_dir, 'Game305.vol'), os.path.join(out_dir, 'SquigglePants', 'Game305.vol'))

def main(vol_path, titles_path, out_dir, menus_path=None, code=True):
    """Writes the patched files into out_dir/SquigglePants and, with code, the Riivolution XML (building the patch
    code needs the PowerPC compiler; the release ships the XML ready-made)."""
    orig = open(vol_path, 'rb').read()
    assert len(orig) == 0x62E48F, 'not the US Boot.vol this patch was made from'
    assert write_vol(orig, {}) == orig, 'repacking the untouched archive does not give the same bytes'
    _, _, ents = read_vol(orig)
    files = {e['name'].decode('latin-1'): e['data'] for e in ents}

    # titles: the English column of Names.text
    titles = {t['official']: t['corrected'] for t in json.load(open(titles_path)) if t['official'] != t['corrected']}
    titles.update(EXTRA_TITLES)
    names = files['Names.text']
    _, _, _, rows = read_txts(names)
    changes, found = {}, set()
    for r, e in enumerate(rows):
        s = get_str(names, e[1])
        if s in titles:
            changes[(r, 0)] = titles[s]
            found.add(s)
            print('title: %r -> %r' % (s, titles[s]))
    for s in sorted(set(titles) - found):
        print('NOT FOUND in Names.text: %r' % s)
    new_names = set_strings(names, changes)
    # check: every other string is unchanged
    _, _, _, rows2 = read_txts(new_names)
    for r, (a, b) in enumerate(zip(rows, rows2)):
        for lang in range(len(a) - 1):
            want = changes.get((r, lang), get_str(names, a[1 + lang]))
            assert get_str(new_names, b[1 + lang]) == want

    fixed = {}
    for fname, fixes in UI_FIXES.items():
        t = files[fname]
        _, _, _, trows = read_txts(t)
        ch = {}
        for r, e in enumerate(trows):
            s = get_str(t, e[1])
            if s in fixes:
                ch[(r, 0)] = fixes[s]
                print('%s: %r -> %r' % (fname, s, fixes[s]))
        assert {get_str(t, trows[r][1]) for r, _ in ch} == set(fixes), 'not every line was found in ' + fname
        fixed[fname] = set_strings(t, ch)
    for fname, fixes in ALL_LANGUAGE_FIXES.items():
        t = fixed.get(fname, files[fname])
        nlang, _, _, trows = read_txts(t)
        ch = {}
        for r, e in enumerate(trows):
            s = get_str(t, e[1])
            if s in fixes:
                assert len(fixes[s]) == nlang
                ch.update({(r, lang): text for lang, text in enumerate(fixes[s])})
                print('%s: %r -> %r' % (fname, s, fixes[s][0]))
        assert len(ch) == nlang * len(fixes), 'not every line was found in ' + fname
        fixed[fname] = set_strings(t, ch)

    credits = files['Credits.txt']
    assert credits.count(AFTER) == 1 and WRITER not in credits
    new_credits = credits.replace(AFTER, AFTER + WRITER)
    # the opening heading, the only one in capitals
    assert new_credits.count(DEVELOPED_BY[0]) == 1
    new_credits = new_credits.replace(*DEVELOPED_BY)
    # Jake Kaufman credited as Composer, not "Audio Guy"
    assert new_credits.count(COMPOSER[0]) == 1
    new_credits = new_credits.replace(*COMPOSER)
    # "and" for "&", and a space each side of a slash between two titles ("Lead Artist / Concept Artist")
    new_credits = new_credits.replace(b' & ', b' and ')
    new_credits = re.sub(rb'(\S)/(\S)', rb'\1 / \2', new_credits)
    assert b'&' not in new_credits
    print('credits: added Writer: Luke Brookshier and SpongeBob SquigglePants+: Mitch "WubbzP" Bentz')

    # the title in italics
    import italic
    chars = italic.mapping(TITLES)
    t = fixed['WiiText.text']
    nlang, _, _, trows = read_txts(t)
    ch = {}
    for r, e in enumerate(trows):
        for lang in range(nlang):
            text = get_str(t, e[1 + lang])
            new = italic_titles(text, chars)
            if new != text and e[0] not in NOT_ITALIC:
                ch[(r, lang)] = new
    assert len(ch) == 3 * nlang, 'the title is not where it was in WiiText.text'
    fixed['WiiText.text'] = set_strings(t, ch)
    new_credits = italic_titles(new_credits.decode('utf-8'), chars).encode('utf-8')
    fonts = {}
    for name in ITALIC_FONTS:
        fonts[name], missing = italic.italicise(files[name], chars)
        assert not missing, (name, missing)
    print('italic titles: %d strings; italic letters in %s' % (len(ch) + 1, ', '.join(ITALIC_FONTS + ITALIC_FONTS_ADDED)))

    new_files = dict(fixed, **{'Names.text': new_names, 'Credits.txt': new_credits}, **fonts)
    vol = write_vol(orig, new_files)
    added = {}
    if menus_path:
        _, _, ments = read_vol(open(menus_path, 'rb').read())
        menus = {e['name'].decode('latin-1'): e['data'] for e in ments}
        for name in ITALIC_FONTS_ADDED:
            used = TITLES[0] if name == 'Sponge36.font' else ''.join(TITLES)  # the credits are only in English
            added[name], missing = italic.italicise(menus[name], {c: p for c, p in chars.items() if c in used})
            assert not missing, (name, missing)
            vol = add_file(vol, name, added[name])
    _, _, check = read_vol(vol)
    want = dict(files, **new_files, **added)
    assert {e['name'].decode('latin-1'): e['data'] for e in check} == want

    if code:
        os.makedirs(os.path.join(out_dir, 'riivolution'), exist_ok=True)
    os.makedirs(os.path.join(out_dir, 'SquigglePants'), exist_ok=True)
    open(os.path.join(out_dir, 'SquigglePants', 'Boot.vol'), 'wb').write(vol)
    if code:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'code'))
        import cave
        patches = cave.main()
        xml = XML
        for pid in patches:
            xml = xml.replace('@%s@' % pid.upper(), patches[pid])
        open(os.path.join(out_dir, 'riivolution', 'SquigglePants.xml'), 'w', newline='\n').write(xml)
    if menus_path:
        patch_menus(menus_path, out_dir)
        make_extras(os.path.dirname(os.path.abspath(menus_path)), out_dir)
    print('wrote', out_dir, '(Boot.vol %d bytes)' % len(vol))

if __name__ == '__main__':
    main(*sys.argv[1:5])
