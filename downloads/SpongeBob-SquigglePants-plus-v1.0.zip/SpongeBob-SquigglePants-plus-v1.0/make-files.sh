#!/bin/sh
# Makes the patched files (the SquigglePants folder) from your own copy of the game. Needs Python 3.
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is needed. Get it free from https://www.python.org/downloads/"
  exit 1
fi
if ! python3 -c "import PIL, numpy" >/dev/null 2>&1; then
  echo "Installing the Python packages Pillow and NumPy, once..."
  python3 -m pip install --user pillow numpy || exit 1
fi
python3 tools/make_files.py
