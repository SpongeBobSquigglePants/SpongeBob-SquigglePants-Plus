// Addresses in the US main.dol (SS8E78) used by the patch code.
#pragma once

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;

#define R13 0x80348a00u
#define VAR(type, addr) (*(volatile type *)(addr))

// game functions (addresses come from game.ld)
extern char *strcpy(char *dst, const char *src);
extern int strcmp(const char *a, const char *b);
extern char *strcat(char *dst, const char *src);
extern const char *GameText(const char *key);  // on-screen text by key, in the current language
extern void SetLanguage(int scLanguage);  // 0x8005cc34: 1 English, 2 German, 3 French, 4 Spanish, 5 Italian, 6 Dutch
extern void SaveAllSlots(void);           // 0x8005bea0: writes the three save slots to NAND
extern int sprintf(char *dst, const char *fmt, ...);
extern void VolOpen(u32 *handle, const char *name, int wait);  // mounts a .vol from the disc
extern void VolClose(u32 handle);
extern void PendingVol(u32 *handle);  // a mounted .vol still loading (with a reference), or 0
extern void PresentFrame(void);
extern const float *StickVector(int chan);  // 0x8017e028: the Nunchuk stick, x and y
extern void TimedNanogame(int id);  // 0x80019040, the Dev Menu's timed launcher

// memory, images and UI elements
extern void *Alloc(u32 size, const char *file, int line);  // operator new
extern void LoadImage(u32 *handle, const char *name, int wait);
extern void ReleaseImage(u32 handle);
extern void *DialogElement(void *dialog);  // the dialog's own element, the parent of its widgets
extern void SetEnabled(void *element, int on);
extern void SetId(void *element, int id);  // the id a dialog returns when the element is picked
extern void AddChild(void *parent, void *child);
extern void SetPosition(void *element, const float *xy);  // screen centre is (0, 0), y up
extern void SetNavigation(void *dialog, int id, int up, int down, int left, int right);  // D-pad links

// Replay
extern void *FrameButton(void *mem, void *layer, void *parent, u32 *image);  // a section frame on the picker
extern void SetFrameScale(void *button, float scale);
extern void AddFrameOverlay(void *button, u32 *image);  // the medal over a frame
extern int WorstMedal(void *dialog, const int *ids, int n);  // 0 none or bronze, 1 bronze, 2 silver, 3 gold
extern void InputLayer(void *layer);
extern void InputLayerDone(void *layer);
extern void InputLayerDelete(void *layer, int how);
extern void PageExtra(void *obj);
extern void PageExtraDelete(void *obj, int how);
extern void ScreenSize(float *wh);
extern void GameDialog(void *dialog, void *layer, int *ids, int n, int world, int flags, float a, float b);
extern void GameDialogFocus(void *dialog, int id);
extern void GameDialogDelete(void *dialog, int how);
extern int RunDialog(void *dialog);
extern void FadeIn(void);
extern u8 *CurrentSlot(void);  // the save slot in use
extern void ShowGameIntro(int id);
extern void FadeMusic(int frames);
extern u32 PlayReplayGame(int id, int page);  // returns the score
extern int BronzeScore(int id);
extern int SilverScore(int id);
extern int GoldScore(int id);
extern void AfterReplayGame(int arg);
extern void PlayMusic(const char *name, float volume);
extern int MusicReady(void);
extern void LoadFile(void *file, const char *name, int wait);
extern void MusicInit(void *file);
extern void FileDelete(void *file, int how);
extern void ReplayController(void);  // 0x800765c4: the whole Replay menu

// dialogs, their input layers, and the Options and Credits screens
extern void *TextButton(void *dialog, int id, const char *text);  // a pause-menu style button, added to the dialog
extern void *BackTab(void *mem, void *layer, void *parent);  // the "B Back" tab (0x24c bytes)
extern void ElementMatrix(void *element, const float *m);  // 2x2: scale and rotation
extern void DialogInit(void *dialog, void *layer, void *parent, int flags);  // the plain dialog (0x160 bytes)
extern void DialogReset(void *dialog);  // forget what was picked, before running it (again)
extern void DialogInput(void *dialog);  // one frame of the dialog's input; what is picked goes to +0x11c
extern void DialogDelete(void *dialog, int how);
extern void LayerUpdate(void *layer);
extern void LayerDraw(void *layer);
extern void FadeOut(void);
extern int FadeDone(void);
extern void Credits(void);
extern void OptionsDialog(void *dialog, void *layer, int a, int b);  // 0x800753ac, its constructor  // 0x8005eb24: the scrolling credits (Credits.cpp)
#define PEN_LIST 0x80350450u
extern void *Pen(u32 list, int chan);  // the uDraw pen
extern const float *PenPosition(void *pen);  // on screen: centre (0, 0), y up
extern int PenDown(void);
extern int PenPressed(void);  // this frame

// IconBob's Replay records in the current save slot (iconbob_save.c): kind, game (0-6 for 301-307)
enum { ICONBOB_PLAYED, ICONBOB_BRONZE, ICONBOB_SILVER, ICONBOB_GOLD, ICONBOB_BEST };
int iconbob_get(int kind, int j);
void iconbob_set(int kind, int j, int value);

// input: the buttons held on the Wii Remote, in WPAD order
#define INPUT_MGR VAR(u32, R13 - 0x1df0)
#define HELD_BUTTONS() VAR(u32, INPUT_MGR + 0xcfc)
enum {
  BTN_LEFT = 0x0001, BTN_RIGHT = 0x0002, BTN_DOWN = 0x0004, BTN_UP = 0x0008, BTN_PLUS = 0x0010,
  BTN_2 = 0x0100, BTN_1 = 0x0200, BTN_B = 0x0400, BTN_A = 0x0800, BTN_MINUS = 0x1000, BTN_HOME = 0x8000,
};

// save data: three slots of 0x508 bytes
#define SAVE_SLOTS 0x80352d30u
#define SAVE_SLOT_SIZE 0x508
