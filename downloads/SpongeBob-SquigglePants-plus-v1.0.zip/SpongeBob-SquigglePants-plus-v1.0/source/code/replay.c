// IconBob in Nanogame Replay. The game was made ready for an eighth Replay section, id 7, for IconBob (the Nintendo 3DS
// world, nanogames 301-307, which are on the Wii disc and play): the picker's nameplate ("Icon") and "N% Unlocked"
// box have a case for it, the grid has icons for it (world 6: world_08_game_3xx), the player mounts World7.vol for
// page 6, and the code that reads and writes the save maps ids above 300. But the frame was never added, and the
// save slot has no room laid out for the records, so they are kept in its spare bits (iconbob_save.c).
#include "game.h"

#define SECTION_ICONBOB 7
#define REPLAY_BACK 10000  // what the dialogs return for Back
#define ICONBOB_PAGE 6     // the player mounts World7.vol, IconBob's world, for page 6; the grid shows its icons
#define FIRST_3DS 301


// the frames' places, by section: World 1-4 on top, World 5, World 6, IconBob and Remix below (IconBob before Remix,
// as on the 3DS)
static const float frame_pos[8][2] = {
    {-240, 75}, {-80, 75}, {80, 75}, {240, 75},
    {-240, -65}, {-80, -65}, {240, -65}, {80, -65},
};

static const int iconbob_ids[] = {301, 302, 303, 304, 305, 306, 307};
#define ICONBOB_COUNT (int)(sizeof iconbob_ids / sizeof iconbob_ids[0])

static void *new_frame(void *dialog, void *layer, const char *image, int id, const int *ids, int n) {
  u32 img = 0;
  void *button = Alloc(0x454, "ReplaySelectDialog.cpp", 0x81);
  if (!button) return 0;
  LoadImage(&img, image, 1);
  FrameButton(button, layer, DialogElement(dialog), &img);
  if (img) ReleaseImage(img);
  SetEnabled(button, 1);
  SetFrameScale(button, 0.65f);
  SetId(button, id);
  AddChild(dialog, button);
  // the medal of the section's worst game
  static const char *const medal_image[] = {
      0, "replay_frame_04_bronze.image", "replay_frame_03_silver.image", "replay_frame_02_gold.image"};
  int medal = WorstMedal(dialog, ids, n);
  if (medal >= 1 && medal <= 3) {
    u32 m = 0;
    LoadImage(&m, medal_image[medal], 1);
    AddFrameOverlay(button, &m);
    if (m) ReleaseImage(m);
  }
  return button;
}

// Runs after the picker is built (the dialog at `dialog`, its input layer at `layer`).
void replay_picker_extra(void *dialog, void *layer) {
  void **frames = (void **)((u8 *)dialog + 0x18c);  // ids 0-6
  float pos[2];
  for (int i = 0; i < 7; i++) {
    pos[0] = frame_pos[i][0];
    pos[1] = frame_pos[i][1];
    if (frames[i]) SetPosition(frames[i], pos);
  }
  // the thumbnail made for it: SpongeBob and Patrick on a stage
  void *iconbob = new_frame(dialog, layer, "replay_frame_08_a.image", SECTION_ICONBOB, iconbob_ids, ICONBOB_COUNT);
  if (iconbob) {
    pos[0] = frame_pos[SECTION_ICONBOB][0];
    pos[1] = frame_pos[SECTION_ICONBOB][1];
    SetPosition(iconbob, pos);
  }
  // D-pad links for the new frame (the others' are changed in the dialog's own code, see cave.py): up, down,
  // left, right
  SetNavigation(dialog, SECTION_ICONBOB, 2, 2, 5, 6);
}

// One section's page of games, as the game's own page functions (0x800740b8 and the like) show them.
static int replay_page(int last, const int *ids, int n, int world) {
  u8 layer[0x40] __attribute__((aligned(8)));
  u8 extra[0x20] __attribute__((aligned(8)));
  u8 dialog[0x600] __attribute__((aligned(8)));
  int list[16];
  float screen[2];
  for (int i = 0; i < n; i++) list[i] = ids[i];
  InputLayer(layer);
  PageExtra(extra);
  ScreenSize(screen);
  GameDialog(dialog, layer, list, n, world, 0, screen[0] * 0.5f, 0.5f);
  FadeIn();
  GameDialogFocus(dialog, last == REPLAY_BACK ? list[0] : last);
  int id = RunDialog(dialog);
  InputLayerDone(layer);
  GameDialogDelete(dialog, -1);
  PageExtraDelete(extra, -1);
  InputLayerDelete(layer, -1);
  return id;
}

// Plays an IconBob game from Replay and keeps its best score and medals, as the Replay controller does for the
// others.
static void replay_play_3ds(int id) {
  int i = id - FIRST_3DS;
  if (!iconbob_get(ICONBOB_GOLD, i)) ShowGameIntro(id);
  FadeMusic(0x3c);
  u32 score = PlayReplayGame(id, ICONBOB_PAGE);
  // Replay doesn't mark games played (the story mode does, and IconBob has none on the Wii); its "N% Unlocked"
  // counts the ones played here
  iconbob_set(ICONBOB_PLAYED, i, 1);
  if ((int)score > iconbob_get(ICONBOB_BEST, i)) iconbob_set(ICONBOB_BEST, i, score);
  if ((int)score >= BronzeScore(id)) iconbob_set(ICONBOB_BRONZE, i, 1);
  if ((int)score >= SilverScore(id)) iconbob_set(ICONBOB_SILVER, i, 1);
  if ((int)score >= GoldScore(id)) iconbob_set(ICONBOB_GOLD, i, 1);
#ifndef TEST_REPLAY  // test builds: the save isn't set up, and this would load the slots back over the test's
  AfterReplayGame(0);
#endif
  PlayMusic("SEQ_FRONTEND_MENU", 1.0f);
}

static int last_iconbob = REPLAY_BACK;

// Called by the Replay controller for a section number it doesn't know.
void replay_extra_section(int section) {
  if (section != SECTION_ICONBOB) return;
#ifdef TEST_PLAY_ID  // test builds: play one game straight away
  replay_play_3ds(TEST_PLAY_ID);
  return;
#endif
  for (;;) {
    int id = replay_page(last_iconbob, iconbob_ids, ICONBOB_COUNT, ICONBOB_PAGE);
    if (id == REPLAY_BACK) return;
    last_iconbob = id;
    replay_play_3ds(id);
  }
}
