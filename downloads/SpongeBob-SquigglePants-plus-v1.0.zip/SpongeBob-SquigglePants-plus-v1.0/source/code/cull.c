// Letters far above or below the screen aren't drawn. The game draws every letter of a text, wherever it is, and
// the credits after PixelBob's ending (Movies entry 7) are one text of about 6,500 letters, drawn every frame from
// the start of the movie, while they wait below the screen, to the end of the roll, when a few hundred are on
// screen: the game drops to a few frames a second. The test is on the letter's position matrix (a 3x3 matrix, then
// the position: screen pixels, centre (0, 0), y up), with a wide margin, so nothing that could show is left out.
#include "game.h"

#define HALF_HEIGHT 240.0f  // the screen's
#define MARGIN 256.0f       // more than any letter's size, in the letter's own units

#ifdef TEST_CULL
u32 cull_drawn, cull_skipped;  // read with the debugger
#endif

static float fabs_(float x) {
  return x < 0 ? -x : x;
}

// m: the letter's position matrix. Whether any of it can be on screen.
int letter_visible(const float *m) {
  float reach = HALF_HEIGHT + MARGIN * (fabs_(m[1]) + fabs_(m[4]));
  int visible = fabs_(m[10]) <= reach;
#ifdef TEST_CULL
  if (visible) cull_drawn++;
  else cull_skipped++;
#endif
  return visible;
}
