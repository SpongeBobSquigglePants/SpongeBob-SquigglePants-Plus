// The Options screen's extras: a "Credits" button under the volume sliders shows the game's own scrolling credits
// (Credits.cpp, left in the game for the Dev Menu only), which can also be scrolled by hand and left with B or the
// Back tab, as in Patchy's gallery. Watching them to the end hangs a picture frame on the wall that plays Puzzle de
// Pants, the cut nanogame (game 95).
#include "game.h"

// The ids the dialog gives back. Not 0: the dialog's input handling can pick id 0 by itself (it starts its D-pad
// focus there), which the game's Options screen, with nothing of id 0, ignores; the first D-pad press goes from it
// to the Credits button.
#define OPT_START 0
#define OPT_CREDITS 1
#define OPT_PUZZLE 2
#define PUZZLE_ID 95
#define PUZZLE_PAGE 7  // the Replay player mounts RemixA.vol, the Remix world's, for page 7 and up
#define LANGUAGE VAR(u32, R13 - 0x1d40)  // the text column GameText reads: English, French, German, Italian,
                                         // Dutch, Spanish
// The save slot ends in three bytes of padding after Art Studio's stamp flags (0x3d3-0x504); the last one's bit 0
// says the credits have been watched to the end.
#define UNLOCK_BYTE 0x507
#define PUZZLE_UNLOCKED 0x01

static const char *const credits_label[] = {"Credits", "Crédits", "Credits", "Crediti", "Credits", "Créditos"};

static void *options_layer;
static void *puzzle_frame;

static int puzzle_unlocked(void) {
  return CurrentSlot()[UNLOCK_BYTE] & PUZZLE_UNLOCKED;
}

static void scale(void *element, float s) {
  float m[4] = {s, 0, 0, s};
  ElementMatrix(element, m);
}

// The Puzzle de Pants frame, on the wall to the right of the panel, where the anchor picture hangs.
static void add_puzzle_frame(void *dialog) {
  u32 img = 0;
  float pos[2] = {345, 20};
  void *frame = Alloc(0x454, "OptionsDialog.cpp", 1);
  if (!frame) return;
  LoadImage(&img, "options_frame_puzzle.image", 1);
  FrameButton(frame, options_layer, DialogElement(dialog), &img);
  if (img) ReleaseImage(img);
  SetEnabled(frame, 1);
  SetFrameScale(frame, 0.65f);
  SetId(frame, OPT_PUZZLE);
  AddChild(dialog, frame);
  SetPosition(frame, pos);
  puzzle_frame = frame;
  // D-pad links (up, down, left, right): between the button and the frame
  SetNavigation(dialog, OPT_CREDITS, OPT_CREDITS, OPT_CREDITS, OPT_CREDITS, OPT_PUZZLE);
  SetNavigation(dialog, OPT_PUZZLE, OPT_PUZZLE, OPT_PUZZLE, OPT_CREDITS, OPT_PUZZLE);
}

// Runs at the end of the Options dialog's constructor (the dialog at `dialog`, its input layer at `layer`).
void options_extra(void *dialog, void *layer) {
  options_layer = layer;
  puzzle_frame = 0;
  u32 lang = LANGUAGE;
  void *b = TextButton(dialog, OPT_CREDITS, credits_label[lang < 6 ? lang : 0]);
  SetNavigation(dialog, OPT_START, OPT_CREDITS, OPT_CREDITS, OPT_CREDITS, OPT_CREDITS);
  if (b) {
    // under the SFX slider (the sliders are moved up for it, see cave.py)
    float pos[2] = {0, -84};
    scale(b, 0.7f);
    SetPosition(b, pos);
  }
  if (puzzle_unlocked()) add_puzzle_frame(dialog);
}

// Plays Puzzle de Pants as Replay plays a game, keeping nothing: the player only reads the game's best score (to
// show), and game 95's best score word holds IconBob's (iconbob_save.c), so it is hidden for the game's length.
static void play_puzzle(void) {
  u8 *best = CurrentSlot() + 0xa8 + 4 * (PUZZLE_ID - 1);
  u8 kept[4];
  for (int i = 0; i < 4; i++) {
    kept[i] = best[i];
    best[i] = 0;
  }
  ShowGameIntro(PUZZLE_ID);
  FadeMusic(0x3c);
  PlayReplayGame(PUZZLE_ID, PUZZLE_PAGE);
  best = CurrentSlot() + 0xa8 + 4 * (PUZZLE_ID - 1);
  for (int i = 0; i < 4; i++) best[i] = kept[i];
}

static int credits_finished;  // set by credits_end: the credits were watched to the end

// Replaces the Options screen's "bl RunDialog" (0x80086418): runs what the button or the frame picks, then the
// dialog again.
int options_run(void *dialog) {
  for (;;) {
    int id = RunDialog(dialog);
    if (id == OPT_PUZZLE && puzzle_frame) {
      play_puzzle();
    } else if (id == OPT_CREDITS) {
      credits_finished = 0;
      Credits();
      if (credits_finished && !puzzle_unlocked()) {
        CurrentSlot()[UNLOCK_BYTE] |= PUZZLE_UNLOCKED;
#ifndef TEST_OPTIONS  // test builds: the save isn't set up, and this would load the slots back over the unlock
        AfterReplayGame(0);  // saves
#endif
      }
      if (puzzle_unlocked() && !puzzle_frame) add_puzzle_frame(dialog);
    } else {
      return id;
    }
    PlayMusic("SEQ_FRONTEND_MENU", 1.0f);
    DialogReset(dialog);
    FadeIn();
  }
}

// ---------------------------------------------------------------- the credits screen

// The Credits screen's loop (0x8005eb24) moves the text up a pixel a frame (y is its top, from -240 below the
// screen) and fades out once it has gone by; these add a Back tab and scrolling by hand to it.
static struct {
  void *layer, *dialog;
  float back[2];  // where the Back tab is
  float last_pen_y;
  int dragging;
  int idle;  // frames since the last scroll by hand
  int left;  // B or the Back tab: the credits were left before the end
} cr;

static u8 cr_layer[0x1c0] __attribute__((aligned(8)));
static u8 cr_dialog[0x180] __attribute__((aligned(8)));

// Replaces the loop's "bl FadeIn" (0x8005ece8), once the text is laid out.
void credits_begin(void) {
  float screen[2], pos[2];
  cr.layer = cr_layer;
  cr.dialog = cr_dialog;
  cr.dragging = 0;
  cr.idle = 30;
  cr.left = 0;
  InputLayer(cr.layer);
  DialogInit(cr.dialog, cr.layer, 0, 0);
  void *back = Alloc(0x24c, "Credits.cpp", 1);
  if (back) {
    back = BackTab(back, cr.layer, DialogElement(cr.dialog));
    AddChild(cr.dialog, back);
    // where the Options screen has it: the bottom left corner
    ScreenSize(screen);
    pos[0] = 115 - screen[0] * 0.5f;
    pos[1] = 60 - screen[1] * 0.5f;
    SetPosition(back, pos);
    cr.back[0] = pos[0];
    cr.back[1] = pos[1];
  }
  DialogReset(cr.dialog);
  FadeIn();
}

#ifndef SCROLL_SPEED  // (test builds can make it faster)
#define SCROLL_SPEED 6.0f  // pixels a frame with the D-pad
#endif
#define TOP (-240.0f)      // the text's first place, just below the screen
#define RESUME 30          // frames after the last scroll by hand that it carries on by itself

#define BACK_HALF_W 60  // half the Back tab's size, for taps on it
#define BACK_HALF_H 25

// Replaces "fadds f28, f28, f29" (0x8005ed10), the text's step up: given its place, returns the next one. (The
// dialog only holds the Back tab: its own input handling would pick its first id, which it doesn't have, on A.)
float credits_step(float y) {
  LayerUpdate(cr.layer);
  int leave = VAR(u32, INPUT_MGR + 0xcf4) & BTN_B;
  if (PenPressed()) {
    const float *p = PenPosition(Pen(PEN_LIST, 0));
    float dx = p[0] - cr.back[0], dy = p[1] - cr.back[1];
    if (dx > -BACK_HALF_W && dx < BACK_HALF_W && dy > -BACK_HALF_H && dy < BACK_HALF_H) leave = 1;
  }
  if (leave && !cr.left) {
    cr.left = 1;
    FadeOut();
  }
  float moved = 0;
  int by_hand = 0;
  u32 held = VAR(u32, INPUT_MGR + 0xcf0);
  if (held & BTN_UP) {
    moved -= SCROLL_SPEED;
    by_hand = 1;
  }
  if (held & BTN_DOWN) {
    moved += SCROLL_SPEED;
    by_hand = 1;
  }
  // dragging the text with the pen: it follows the pen up and down
  if (PenDown()) {
    float pen_y = PenPosition(Pen(PEN_LIST, 0))[1];
    if (cr.dragging) moved += pen_y - cr.last_pen_y;
    cr.last_pen_y = pen_y;
    cr.dragging = 1;
    by_hand = 1;
  } else {
    cr.dragging = 0;
  }
  if (by_hand) cr.idle = 0;
  else if (cr.idle < RESUME) cr.idle++;
  if (cr.idle >= RESUME) moved = 1;
  y += moved;
  return y < TOP ? TOP : y;
}

// Replaces the loop's "bl PresentFrame" (0x8005ee00): draws the Back tab over the text.
void credits_present(void) {
  LayerDraw(cr.layer);
  PresentFrame();
}

// Replaces "bl FadeMusic" (0x8005ee14), once the screen has faded out.
void credits_end(int frames) {
  credits_finished = !cr.left;
  InputLayerDone(cr.layer);
  DialogDelete(cr.dialog, -1);
  InputLayerDelete(cr.layer, -1);
  FadeMusic(frames);
}
