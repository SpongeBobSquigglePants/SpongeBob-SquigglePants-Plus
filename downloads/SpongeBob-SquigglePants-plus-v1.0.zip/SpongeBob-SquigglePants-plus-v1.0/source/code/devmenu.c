// The Dev Menu left in the game (Boot, Title Screen, Play Game, Tests, nanogame lists...). It still draws, but
// the code that moved the cursor and picked an entry was taken out of the release build, so this puts it back:
// up/down move (held to repeat), left/right jump ten, A picks, B goes back. devmenu_frame() runs once a frame from
// the menu's loop and returns the name of a picked entry, which the game's main loop then starts.
#include "game.h"

typedef struct {
  const char *name;
  const void *sub;  // a list of entries, ended by a null name, or 0
} Entry;

// the menu's own variables
#define MENU_NODE (*(Entry ***)(R13 - 0x7828))  // [0] = the entries on screen
#define MENU_SEL VAR(u32, R13 - 0x1e34)
#define MENU_COUNT VAR(u32, R13 - 0x1e30)
#define MENU_LANG VAR(u8, R13 - 0x1e38)
#define TIMED_GAMES VAR(u8, R13 - 0x8000)
#define WIDESCREEN VAR(u8, R13 - 0x135c)

// the four entries whose names are written at run time, and the names the game picks between
#define LABEL_TIMED ((char *)0x8034ee80)
#define LABEL_WIDE ((char *)0x8034eea0)
#define LABEL_UNLOCK ((char *)0x8034eec0)
#define LABEL_LANG ((char *)0x8034eee0)
#define STR_BASE 0x802ef0c0u
#define STR(off) ((const char *)(STR_BASE + (off)))
#define LANG_NAMES ((const char **)STR_BASE)

#define MAX_DEPTH 8
static const Entry *stack_list[MAX_DEPTH];
static u32 stack_sel[MAX_DEPTH];
static u32 depth;
static u32 prev_held;
static int repeat_wait;
static u32 message_frames;

static u32 count_entries(const Entry *list) {
  u32 n = 0;
  while (list[n].name) n++;
  return n;
}

static void show(const Entry *list, u32 sel) {
  *MENU_NODE = (Entry *)list;
  MENU_COUNT = count_entries(list);
  MENU_SEL = sel;
}

static void go_back(void) {
  if (depth == 0) return;
  depth--;
  show(stack_list[depth], stack_sel[depth]);
}

static void open_sub(const Entry *sub) {
  if (depth == MAX_DEPTH) return;
  stack_list[depth] = *MENU_NODE;
  stack_sel[depth] = MENU_SEL;
  depth++;
  show(sub, 1);  // entry 0 is ".."
}

static void fill(u8 *p, u32 n, u8 v) {
  while (n--) *p++ = v;
}

static void fill_words(u32 *p, u32 n, u32 v) {
  while (n--) *p++ = v;
}

// The same as the 100% save Gecko code, for every slot: all worlds, Remix and Hyper cleared, every nanogame played
// with a Replay best of 101, every minigame best at 100, every medal, every Patchy movie and the 100% movie.
static void unlock_all(void) {
  for (u32 s = 0; s < 3; s++) {
    u8 *slot = (u8 *)(SAVE_SLOTS + s * SAVE_SLOT_SIZE);
    *(u32 *)(slot + 0x10) = 6;
    fill(slot + 0x15, 0x6f, 1);
    fill_words((u32 *)(slot + 0x84), 8, 75);
    fill_words((u32 *)(slot + 0xa8), 0x6f, 101);
    fill_words((u32 *)(slot + 0x264), 4, 100);
    fill(slot + 0x274, 0x14d, 1);
    fill(slot + 0x3c8, 0x0b, 1);
  }
  SaveAllSlots();
  strcpy(LABEL_UNLOCK, "UnlockAll (done)");
  message_frames = 120;
}

// Returns 1 if the entry was one of the settings, which change in place.
static int toggle(const char *name) {
  if (name == LABEL_TIMED) {
    TIMED_GAMES = !TIMED_GAMES;
    strcpy(LABEL_TIMED, TIMED_GAMES ? STR(0x1f8) : STR(0x204));
  } else if (name == LABEL_WIDE) {
    WIDESCREEN = !WIDESCREEN;
    strcpy(LABEL_WIDE, WIDESCREEN ? STR(0x214) : STR(0x224));
  } else if (name == LABEL_UNLOCK) {
    unlock_all();
  } else if (name == LABEL_LANG) {
    MENU_LANG = (MENU_LANG + 1) % 6;
    SetLanguage(MENU_LANG + 1);
    strcpy(LABEL_LANG, LANG_NAMES[MENU_LANG]);
  } else {
    return 0;
  }
  return 1;
}

const char *devmenu_frame(void) {
#ifdef AUTOPICK
  // test builds only: pick an entry by name on the first frame
  static int picked;
  if (!picked) {
    picked = 1;
#if defined(TEST_REPLAY) || defined(TEST_OPTIONS)
    // straight into Replay (or Options), with every save slot unlocked in memory
    u32 menus = 0, micro = 0;
    VolOpen(&menus, "menus.vol", 1);
    VolOpen(&micro, "Microgames.vol", 1);  // as the title screen's start-up mounts it
    for (;;) {
      u32 pending = 0;
      PendingVol(&pending);
      if (!pending) break;
      VolClose(pending);
      PresentFrame();
    }
    for (u32 s = 0; s < 3; s++) {
      u8 *slot = (u8 *)(SAVE_SLOTS + s * SAVE_SLOT_SIZE);
      *(u32 *)(slot + 0x10) = 6;
      fill(slot + 0x15, 0x6f, 1);
    }
    // the music, as the title screen's start-up loads it (0x80007b44)
    if (!MusicReady()) {
      u8 file[0x40] __attribute__((aligned(8)));
      LoadFile(file, "music.brsar", 1);
      MusicInit(file);
      FileDelete(file, -1);
    }
#ifdef TEST_MOVIE  // a Movies entry, as the Movies menu plays it (0x80071e68): TEST_MOVIE is the movie's name
    ((void (*)(int))0x8025b480)(0);
    ((void (*)(void))0x8001306c)();
    ((void (*)(const char *, int, int, int))0x8006d2dc)(TEST_MOVIE, TEST_MOVIE_ARGS);
    for (;;) PresentFrame();
#elif defined(TEST_OPTIONS)  // the Options screen's code, as the front end runs it; TEST_OPTIONS is options_run
#ifdef TEST_UNLOCK
    for (u32 s = 0; s < 3; s++) ((u8 *)(SAVE_SLOTS + s * SAVE_SLOT_SIZE))[0x507] |= 1;
#endif
    u8 layer[0x1c0] __attribute__((aligned(8)));
    u8 dialog[0x400] __attribute__((aligned(8)));
    for (int i = 0; i < 30; i++) PresentFrame();  // till A, which picked this, is let go
    InputLayer(layer);
    OptionsDialog(dialog, layer, 0, 0);
    FadeIn();
    for (;;) {
      DialogReset(dialog);
      ((int (*)(void *))TEST_OPTIONS)(dialog);
    }
#else
    ReplayController();
#endif
    return 0;
#else
    return AUTOPICK;
#endif
  }
#endif
  u32 held = HELD_BUTTONS();
  u32 pressed = held & ~prev_held;
  prev_held = held;
  if (message_frames && --message_frames == 0) strcpy(LABEL_UNLOCK, STR(0x234));

  // held directions repeat after a short wait
  const u32 dirs = BTN_UP | BTN_DOWN | BTN_LEFT | BTN_RIGHT;
  if (pressed & dirs) {
    repeat_wait = 18;
  } else if (held & dirs) {
    if (--repeat_wait <= 0) {
      repeat_wait = 4;
      pressed |= held & dirs;
    }
  }

  const Entry *list = *MENU_NODE;
  int n = (int)count_entries(list);
  int sel = (int)MENU_SEL;
  if (pressed & BTN_UP) sel = sel > 0 ? sel - 1 : n - 1;
  if (pressed & BTN_DOWN) sel = sel < n - 1 ? sel + 1 : 0;
  if (pressed & BTN_LEFT) sel = sel >= 10 ? sel - 10 : 0;
  if (pressed & BTN_RIGHT) sel = sel + 10 < n ? sel + 10 : n - 1;
  MENU_SEL = (u32)sel;

  if (pressed & BTN_B) {
    go_back();
  } else if (pressed & BTN_A) {
    const Entry *e = &list[sel];
    if (strcmp(e->name, "..") == 0) {
      go_back();
    } else if (e->sub) {
      open_sub((const Entry *)e->sub);
    } else if (!toggle(e->name)) {
      return e->name;
    }
  }
  return 0;
}

// The Dev Menu's timed launcher (0x80019040) only mounts Microgames.vol, which no longer holds the nanogames
// (each has its own GameNN.vol on the disc), so it waited for files that never came. This mounts the game's
// archive around it, as the untimed launcher does.
void devmenu_timed_game(int id) {
  char name[16];
  u32 vol = 0;
  sprintf(name, "Game%02u.vol", id);
  VolOpen(&vol, name, 1);
  TimedNanogame(id);
  if (vol) VolClose(vol);
}
