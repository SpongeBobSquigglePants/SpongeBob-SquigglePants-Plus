# Builds the patch code into unused space in main.dol and turns it into Riivolution memory patches.
#   python3 cave.py [main.dol to patch, for testing]
# Each group of code goes into a "cave": a run of library functions that nothing in the game calls or points to
# (checked with cavecheck.py). The groups, their hooks and the XML they produce are listed in PATCHES below.
import os
import re
import struct
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CC = 'powerpc-linux-gnu-gcc'
LD = 'powerpc-linux-gnu-ld'
OBJCOPY = 'powerpc-linux-gnu-objcopy'
NM = 'powerpc-linux-gnu-nm'
CFLAGS = ['-mcpu=750', '-mbig-endian', '-O2', '-ffreestanding', '-fno-builtin', '-nostdlib', '-msdata=none', '-G', '0',
          '-fno-pic', '-mno-relocatable', '-fno-asynchronous-unwind-tables', '-fno-exceptions', '-mhard-float',
          '-Wall', '-Wextra', '-Werror', '-std=gnu11', '-I', os.path.join(HERE, 'build')]
# f14-f31 are kept by the game's functions as paired singles (two floats each), which a plain save and restore of
# a double would cut in half: the patch code doesn't use them
CFLAGS += ['-ffixed-fr%d' % n for n in range(14, 32)]

# caves: start, end (exclusive)
CAVES = {
    'A': (0x802d8820, 0x802d9740),
    'B': (0x802d5ec0, 0x802d6c20),
    'C': (0x801d3840, 0x801d4ae0),
    'D': (0x8028f470, 0x8028f570),
    'E': (0x8028f570, 0x8028fc10),
}

def bl(src, dst):
    off = dst - src
    assert -0x2000000 <= off < 0x2000000 and off % 4 == 0
    return 0x48000001 | (off & 0x3fffffc)

def build(name, sources, cave):
    lo, hi = CAVES[cave]
    out = os.path.join(HERE, 'build')
    os.makedirs(out, exist_ok=True)
    objs = []
    for s in sources:
        o = os.path.join(out, os.path.basename(s) + '.o')
        extra = os.environ.get('CAVE_CFLAGS', '').split()
        subprocess.check_call([CC] + CFLAGS + extra + ['-c', os.path.join(HERE, s), '-o', o])
        objs.append(o)
    elf = os.path.join(out, name + '.elf')
    subprocess.check_call([LD, '-T', os.path.join(HERE, 'game.ld'), '--defsym=CAVE_ADDR=0x%x' % lo, '-o', elf] + objs)
    binf = os.path.join(out, name + '.bin')
    subprocess.check_call([OBJCOPY, '-O', 'binary', '-j', '.cave', elf, binf])
    code = open(binf, 'rb').read()
    while len(code) % 4:
        code += b'\0'
    assert lo + len(code) <= hi, '%s: %d bytes, the cave has %d' % (name, len(code), hi - lo)
    syms = {}
    for line in subprocess.check_output([NM, elf]).decode().splitlines():
        a, t, n = line.split()
        syms[n] = int(a, 16)
    # no relocations may be left for the loader: the code is linked at its final address
    print('%s: %d bytes at 0x%08x (cave %s, %d free)' % (name, len(code), lo, cave, hi - lo - len(code)))
    return lo, code, syms

def memory_xml(addr, data, original=None, indent='\t\t'):
    attrs = 'offset="0x%08X" value="%s"' % (addr, data.hex().upper())
    if original is not None:
        attrs += ' original="%s"' % original.hex().upper()
    return '%s<memory %s />' % (indent, attrs)

# ---------------------------------------------------------------- the patches

def devmenu():
    """Boot into the Dev Menu, with its navigation put back."""
    addr, code, syms = build('devmenu', ['devmenu.c', 'devmenu_hook.S', 'untimed_hook.S'], 'A')
    return [
        (0x80007858, struct.pack('>I', 0x3B600000), struct.pack('>I', 0x3B600001)),  # li r27, 0: start in state 0
        # start in Untimed Games: the timed launcher still hangs (it waits on something besides GameNN.vol)
        (0x80340A00, b'\0', b'\1'),
        (addr, code, None),
        (0x80007390, struct.pack('>I', bl(0x80007390, syms['devmenu_hook'])), struct.pack('>I', 0x48176691)),
        # the timed launcher, called with GameNN.vol mounted
        (0x80007928, struct.pack('>I', bl(0x80007928, syms['devmenu_timed_game'])), struct.pack('>I', 0x48011719)),
        # a way out of the untimed loop ("b" = bl without the link bit)
        (0x8001903c, struct.pack('>I', bl(0x8001903c, syms['untimed_hook']) & ~1), struct.pack('>I', 0x4bffff48)),
    ]

# The picker's D-pad links, set in its constructor by calls of the form mr r3, r28; li r4, id; li r5, up;
# li r6, down; li r7, left; li r8, right; bl SetNavigation. Changed for the new layout, World 1-4 on top and
# World 5, World 6, IconBob (id 7) and Remix (id 6) below, in reading order (IconBob before Remix, as on the 3DS).
PICKER_NAV = {
    # address of "mr r3, r28": the game's (id, up, down, left, right), the new ones
    0x80079874: ((6, 2, 2, 5, 0), (6, 3, 3, 7, 0)),  # when the Remix frame is open
    0x80079890: ((1, 4, 5, 0, 2), (1, 5, 5, 0, 2)),
    0x800798B0: ((6, 1, 1, 1, 0), (6, 3, 3, 7, 0)),  # when it isn't
    0x800798CC: ((1, 6, 6, 0, 6), (1, 5, 5, 0, 2)),
    0x800798E8: ((0, 3, 4, 6, 1), (0, 4, 4, 6, 1)),
    0x80079904: ((2, 5, 6, 1, 3), (2, 7, 7, 1, 3)),
    0x80079920: ((3, 0, 0, 2, 4), (3, 6, 6, 2, 4)),
    0x8007993C: ((4, 1, 0, 3, 5), (4, 0, 0, 3, 5)),
    0x80079958: ((5, 2, 1, 4, 6), (5, 1, 1, 4, 7)),
}

def li_args(vals):
    return b''.join(struct.pack('>I', 0x38000000 | (reg << 21) | v) for reg, v in zip(range(4, 9), vals))

def picker_nav():
    return [(addr + 4, li_args(new), li_args(old)) for addr, (old, new) in PICKER_NAV.items()]

def word(v):
    return struct.pack('>I', v)

# Where the game loads or stores an IconBob record (ids above 300) in the save slot, where there are none: each is
# sent to iconbob_site (iconbob_save.c), which does it on IconBob's own records. (address, original instruction)
ICONBOB_SITES = [
    (0x800725E8, 0x88840015),  # lbz r4, 0x15(r4): played (the game grid)
    (0x80072628, 0x88030352),  # lbz r0, 0x352(r3): gold
    (0x80072670, 0x880302E3),  # lbz r0, 0x2e3(r3): silver
    (0x800726B8, 0x88030274),  # lbz r0, 0x274(r3): bronze
    (0x80074F8C, 0x88030352),  # the same three in the game panel
    (0x80074FA8, 0x880302E3),
    (0x80074FC4, 0x88030274),
    (0x80074F38, 0x80A500A8),  # lwz r5, 0xa8(r5): best (the game panel)
    (0x80074F5C, 0x80A500A8),
    (0x80079AF0, 0x88030352),  # the medal on a section's frame
    (0x80079B0C, 0x880302E3),
    (0x80079B28, 0x88030274),
    (0x80077C54, 0x88030015),  # lbz r0, 0x15(r3): played ("N% Unlocked", IconBob's case)
    (0x80073840, 0x88030273),  # lbz r0, 0x273(r3): bronze (a game's goals)
    (0x80073928, 0x880302E2),  # lbz r0, 0x2e2(r3): silver
    (0x8005F170, 0x9803FF57),  # stb r0, -0xa9(r3): played (the Replay player)
    (0x8005F270, 0x9AA4FF57),  # stb r21, -0xa9(r4)
    (0x8005F374, 0x830300A8),  # lwz r24, 0xa8(r3): best
    (0x80086938, 0x9803FF57),  # stb r0, -0xa9(r3): played (the world player)
    (0x80086A64, 0x9AA4FF57),
]

# The IconBob games' calls to the stick reader (the 3DS circle pad), which iconbob_stick takes over to add the D-pad.
ICONBOB_STICK_CALLS = [0x8013A2A4, 0x8013F228, 0x8013FF34, 0x80141558, 0x80142714]

def iconbob_sites():
    """Writes the site stubs and the table of their instructions into build/."""
    out = os.path.join(HERE, 'build')
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, 'iconbob_sites.h'), 'w') as f:
        f.write('// made by cave.py: the original instruction at each IconBob site\n')
        f.write('static const u32 iconbob_site_insn[] = {%s};\n' % ', '.join('0x%08x' % w for _, w in ICONBOB_SITES))
        f.write('#define ICONBOB_SITE_GRID_PLAYED %d\n' % [a for a, _ in ICONBOB_SITES].index(0x800725E8))
    with open(os.path.join(out, 'iconbob_sites.S'), 'w') as f:
        f.write('# made by cave.py: one stub per IconBob site\n\t.text\n')
        for n, (addr, _) in enumerate(ICONBOB_SITES):
            f.write('\t.globl iconbob_site_%d\niconbob_site_%d:\t# 0x%08x\n' % (n, n, addr))
            f.write('\tstwu 1, -0xb0(1)\n\tstw 0, 0x10(1)\n\tli 0, %d\n\tb iconbob_common\n' % n)
        f.write('\t.section .note.GNU-stack,"",@progbits\n')

def replay():
    """IconBob as the eighth Nanogame Replay section."""
    iconbob_sites()
    addr, code, syms = build('replay', ['replay.c', 'replay_hooks.S', 'iconbob_save.c', 'iconbob_hooks.S',
                                        'build/iconbob_sites.S', 'image_hooks.S'], 'C')
    return [
        (addr, code, None),
        (0x80079BB8, word(bl(0x80079BB8, syms['replay_picker_hook'])), word(0x4BFBAACD)),
        (0x80076660, word(bl(0x80076660, syms['replay_section_hook']) & ~1), word(0x4BFFFFB4)),
        # images drawn at twice their stored size (Candid Krabs' layers, see shrink.py)
        (0x8005ACF0, word(bl(0x8005ACF0, syms['image_scale_hook'])), word(0xD01B0030)),
    ] + [(a, word(bl(a, syms['iconbob_site_%d' % n])), word(w)) for n, (a, w) in enumerate(ICONBOB_SITES)] \
      + [(a, word(bl(a, syms['iconbob_stick'])), word(bl(a, 0x8017E028))) for a in ICONBOB_STICK_CALLS] \
      + picker_nav()

def extras():
    """Mounts SquigglePantsPlus.vol, the patch's own disc file, at start-up (for IconBob in Replay and the Options
    extras, which both include this)."""
    addr, code, syms = build('extras', ['mount.c'], 'D')
    return [
        (addr, code, None),
        (0x800076B4, word(bl(0x800076B4, syms['boot_mount'])), word(0x48177B25)),
    ]

def fl(*v):
    return struct.pack('>%df' % len(v), *v)

def options():
    """The Credits button and the Puzzle de Pants frame on the Options screen."""
    addr, code, syms = build('options', ['options.c', 'options_hooks.S'], 'B')
    return [
        (addr, code, None),
        (0x800759C8, word(bl(0x800759C8, syms['options_ctor_hook'])), word(0x39610140)),
        (0x80086418, word(bl(0x80086418, syms['options_run'])), word(bl(0x80086418, 0x8015C878))),
        # the Options screen's sliders, moved up and closer together to make room for the Credits button under them
        # (the title stays where it was): x and y of the "MUSIC" and "SFX" labels and of the two sliders
        (0x80342060, fl(-170, 25, -170, -30, 70, 27, 70, -28), fl(-170, 13, -170, -67, 70, 15, 70, -65)),
        # the credits screen: the Back tab and scrolling by hand
        (0x8005ECE8, word(bl(0x8005ECE8, syms['credits_begin'])), word(bl(0x8005ECE8, 0x80034684))),
        (0x8005ED10, word(bl(0x8005ED10, syms['credits_step_hook'])), word(0xEF9CE82A)),
        (0x8005EE00, word(bl(0x8005EE00, syms['credits_present'])), word(bl(0x8005EE00, 0x8017DA20))),
        (0x8005EE14, word(bl(0x8005EE14, syms['credits_end'])), word(bl(0x8005EE14, 0x8015F404))),
        # its heading font, Sponge29.font, isn't on the disc: Sponge36.font (menus.vol) instead
        (0x802F56CE, b'36', b'29'),
    ]

# the calls to the letter-drawing function in the text drawing: 0x80163460 (every text element, three: shadow,
# outline and fill) and 0x8016938c (the Credits screen's lines)
LETTER_CALLS = [0x80163844, 0x80163B78, 0x80163E8C, 0x801693EC]

def cull():
    """Letters far off the screen aren't drawn (cull.c)."""
    addr, code, syms = build('cull', ['cull.c', 'cull_hooks.S'], 'E')
    out = [(addr, code, None)]
    for site in LETTER_CALLS:
        out.append((site, word(bl(site, syms['draw_letter'])), word(bl(site, 0x80169400))))
    return out

PATCHES = {'devmenu': devmenu, 'replay': replay, 'extras': extras, 'options': options, 'cull': cull}

# ---------------------------------------------------------------- output

def dol_sections(d):
    offs = struct.unpack('>18I', d[0:0x48])
    addrs = struct.unpack('>18I', d[0x48:0x90])
    sizes = struct.unpack('>18I', d[0x90:0xd8])
    return [(o, a, s) for o, a, s in zip(offs, addrs, sizes) if s]

def apply_to_dol(d, addr, data, original):
    for o, a, s in dol_sections(d):
        if a <= addr and addr + len(data) <= a + s:
            p = o + addr - a
            if original is not None:
                assert d[p:p + len(original)] == original, 'original bytes differ at 0x%08x' % addr
            d[p:p + len(data)] = data
            return
    raise ValueError('0x%08x is not in main.dol' % addr)

def main(dol=None):
    xml = {}
    patched = bytearray(open(dol, 'rb').read()) if dol else None
    for pid, fn in PATCHES.items():
        lines = []
        for addr, data, orig in fn():
            lines.append(memory_xml(addr, data, orig))
            if patched is not None:
                apply_to_dol(patched, addr, data, orig)
        xml[pid] = '\n'.join(lines)
    if patched is not None:
        open(dol, 'wb').write(patched)
        print('patched', dol)
    return xml

if __name__ == '__main__':
    for k, v in main(*sys.argv[1:2]).items():
        print('--', k, len(v), 'chars of XML')
