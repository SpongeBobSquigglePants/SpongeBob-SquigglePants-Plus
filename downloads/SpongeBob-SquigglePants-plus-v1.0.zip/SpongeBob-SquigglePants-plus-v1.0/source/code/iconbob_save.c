// IconBob's Replay records. The save slot's per-game arrays (played 0x15, bronze 0x274, silver 0x2e3, gold 0x352,
// best 0xa8) hold games 1-111 and the slot is full to its last bytes (Art Studio's 306 stamp flags end it); a save
// chunk of their own would change the save file's signature and make every existing save "corrupted". So they are
// kept in what the slot has spare:
//   - game 95 (Puzzle de Pants, cut) is set played with every medal in a new slot and left out of every count, and
//     its flags are only ever tested for zero: bits 1-7 of its played, bronze, silver and gold bytes are IconBob
//     games 301-307 (bit 0 stays as the game sets it);
//   - its best score word (0xa8 + 4 * 94) and the padding after the slot's first byte hold the best scores, a byte
//     each (IconBob rounds stay well under 256).
//
// The game's code already reaches for IconBob records (the developers mapped ids above 300 to indexes 111-117,
// which land on other records); each such load or store is sent to iconbob_site (iconbob_hooks.S) with the original
// instruction, and does it on these instead. The sites and their instructions are listed in cave.py.
#include "game.h"
#include "iconbob_sites.h"

#define CUR_SLOT VAR(u32, R13 - 0x1d48)
static const u16 flag_byte[] = {0x15 + 94, 0x274 + 94, 0x2e3 + 94, 0x352 + 94};  // played, bronze, silver, gold

static u8 *current_slot(void) {
  u32 s = CUR_SLOT;
  return (u8 *)(SAVE_SLOTS + (s < 3 ? s : 0) * SAVE_SLOT_SIZE);
}

static u8 *best_byte(u8 *slot, int j) {
  return j < 4 ? slot + 0xa8 + 4 * 94 + j : slot + 1 + (j - 4);
}

int iconbob_get(int kind, int j) {
  u8 *slot = current_slot();
  if (kind == ICONBOB_BEST) return *best_byte(slot, j);
  return (slot[flag_byte[kind]] >> (j + 1)) & 1;
}

void iconbob_set(int kind, int j, int value) {
  u8 *slot = current_slot();
  if (kind == ICONBOB_BEST) {
    *best_byte(slot, j) = value > 255 ? 255 : (u8)value;
    return;
  }
  u8 bit = 1 << (j + 1);
  if (value) slot[flag_byte[kind]] |= bit;
  else slot[flag_byte[kind]] &= ~bit;
}

// Which IconBob record (kind, game) an access the game makes at `ra + f` is for, or -1 for none.
static int which(u8 *ra, int f, int *j) {
  int idx = ra - current_slot();
  int kind;
  switch (f) {
    // indexed id - 0xbe, the developers' mapping (id - 1 for the others)
    case 0x15: kind = ICONBOB_PLAYED; *j = idx - 111; break;
    case 0x274: kind = ICONBOB_BRONZE; *j = idx - 111; break;
    case 0x2e3: kind = ICONBOB_SILVER; *j = idx - 111; break;
    case 0x352: kind = ICONBOB_GOLD; *j = idx - 111; break;
    // indexed by id
    case -0xa9: kind = ICONBOB_PLAYED; *j = idx - 301; break;  // slot + id - 0xa9 = played[id - 0xbe]
    case 0x273: kind = ICONBOB_BRONZE; *j = idx - 301; break;
    case 0x2e2: kind = ICONBOB_SILVER; *j = idx - 301; break;
    case 0x351: kind = ICONBOB_GOLD; *j = idx - 301; break;
    // best scores, words: the player indexes id - 1, the game panel id - 0xbe
    case 0xa8:
      kind = ICONBOB_BEST;
      *j = idx / 4 >= 300 ? idx / 4 - 300 : idx / 4 - 111;
      break;
    default: return -1;
  }
  return *j >= 0 && *j < 7 ? kind : -1;
}

// Called by the site stubs with the registers (r0-r31, which are put back afterwards) and the site's number.
void iconbob_site(u32 *regs, int n) {
  u32 w = iconbob_site_insn[n];
  int op = w >> 26, rd = (w >> 21) & 31, ra = (w >> 16) & 31;
  short d = w & 0xffff;
  u8 *addr = (u8 *)regs[ra];
  int j, kind = which(addr, d, &j);
  if (kind < 0) {  // not IconBob's: as the instruction does
    if (op == 34) regs[rd] = addr[d];
    else if (op == 38) addr[d] = (u8)regs[rd];
    else if (op == 32) regs[rd] = *(u32 *)(addr + d);
    return;
  }
  // The game grid lets you pick only the games you have played in the story; IconBob has no story mode on the
  // Wii, so its games are always there.
  if (n == ICONBOB_SITE_GRID_PLAYED) regs[rd] = 1;
  else if (op == 38) iconbob_set(kind, j, regs[rd] & 0xff);
  else regs[rd] = iconbob_get(kind, j);
}

// The IconBob games steer with the Nintendo 3DS circle pad, which the Wii version reads as the Nunchuk stick
// (0x8017e028, a direction vector). With the uDraw GameTablet there is no Nunchuk, so the D-pad steers instead
// (a Nunchuk still works). Replaces the five calls to it, all in the IconBob games.
const float *iconbob_stick(int chan) {
  static float v[2];
  const float *s = StickVector(chan);
  if (s[0] * s[0] + s[1] * s[1] > 0.01f) return s;
  u32 held = VAR(u32, INPUT_MGR + 0xcf0);
  float x = (held & BTN_RIGHT ? 1.0f : 0.0f) - (held & BTN_LEFT ? 1.0f : 0.0f);
  float y = (held & BTN_UP ? 1.0f : 0.0f) - (held & BTN_DOWN ? 1.0f : 0.0f);
  if (x != 0 && y != 0) {
    x *= 0.70710678f;
    y *= 0.70710678f;
  }
  v[0] = x;
  v[1] = y;
  return v;
}
