// SquigglePantsPlus.vol, the patch's own disc file: new files that IconBob in Replay and the Options extras use.
#include "game.h"

// Replaces the call that mounts boot.vol at start-up (0x800076b4): also mounts the patch's own files,
// SquigglePantsPlus.vol (a new disc file), for good. The game then waits for both.
void boot_mount(u32 *handle, const char *name, int wait) {
  static u32 extras;
  VolOpen(handle, name, wait);
  VolOpen(&extras, "SquigglePantsPlus.vol", wait);
}
