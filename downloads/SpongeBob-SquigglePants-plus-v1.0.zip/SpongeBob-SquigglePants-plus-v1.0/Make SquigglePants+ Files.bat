@echo off
rem Makes the patched files (the SquigglePants folder) from your own copy of the game. Needs Python 3.
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% --version >nul 2>nul || (
  echo Python 3 is needed. Get it free from https://www.python.org/downloads/
  echo When installing, tick "Add python.exe to PATH".
  pause
  exit /b 1
)
%PY% -c "import PIL, numpy" >nul 2>nul || (
  echo Installing the Python packages Pillow and NumPy, once...
  %PY% -m pip install --user pillow numpy
)
%PY% tools\make_files.py
pause
