SpongeBob SquigglePants+ (Riivolution patch, US version SS8E78)

Version 1.0, 22 October 2026. A free fan-made patch by Mitch "WubbzP" Bentz.
This download holds only the patch: no files from the game. You make the patched game files yourself, once,
from your own copy of the game.

You need:
- your own copy of SpongeBob SquigglePants for the Wii (US, game ID SS8E78) and the uDraw GameTablet;
- a Wii with Riivolution, or the Dolphin emulator;
- Python 3 on your computer (free from https://www.python.org/downloads/; on Windows, tick "Add python.exe to
  PATH" when installing). The first run installs the Python packages Pillow and NumPy.

Installing:
1. Copy four files from your game into the your-game-files folder: Boot.vol, menus.vol, Microgames.vol and
   Game305.vol. In Dolphin, right-click the game, choose Properties, then Filesystem; right-click each file,
   choose Extract File and save it there. (On a Wii, back up your disc with CleanRip first and open the backup
   in Dolphin.)
2. Run "Make SquigglePants+ Files.bat" (Windows) or make-files.sh (Mac or Linux). It checks that the files are
   the US version's and writes the SquigglePants folder (Boot.vol, menus.vol, SquigglePantsPlus.vol and
   Game305.vol).
3. Copy the "riivolution" and "SquigglePants" folders to the root of your SD card (or, for Dolphin, to Dolphin's
   Load/Riivolution folder).
4. Wii: start Riivolution, choose the game, and turn the options on.
   Dolphin: right-click the game, choose "Start with Riivolution Patches...", turn the options on and start.

Options:
- 100% Completion Fix: the save screen's last point needs a best of at least 100 rounds in one Nanogame
  Replay game. It used to need 101 or more, so a save with everything done still showed 99%, though the game's
  own 100% rewards (the last stamps and the last Patchy movie) already unlock at 100. See "What 100% needs".
- Ending Credits Slowdown Fix: the credits after PixelBob's ending (Movies entry 7) are about 6,500 letters,
  and the game drew every one of them every frame, from the start of the movie to the end of the roll, though
  only a few hundred are ever on screen. Letters far off the screen are now skipped.
- Title and Credit Fixes: corrected nanogame titles and menu text ("Press A to Begin", "Select a World" and
  so on), Luke Brookshier's writer credit from the Nintendo 3DS version restored to the credits, and
  Mitch "WubbzP" Bentz credited for SpongeBob SquigglePants+, the credits' opening "Developed by
  WayForward Technologies" out of capitals, "and" for "&" in the credits, and the game's title in italics in
  every language wherever the game writes it (the fonts get slanted copies of its letters).
- SpongeBob SquigglePants+ Logo: the title-screen logo with a "+": in English (US), the high-quality
  SpongeBob SquigglePants+ logo; in the other languages, a "+" after the logo's last word.
- IconBob in Replay: the Nintendo 3DS world IconBob, whose seven nanogames are on the Wii disc, gets the
  eighth Nanogame Replay section the game was made ready for (the frames are now four on top, four below, with
  IconBob before Remix, as on the 3DS). They were made for the 3DS circle pad: steer with the D-pad (a Nunchuk
  works too; the screen before each says "D-PAD!" under the uDraw icon, with Title and Credit Fixes on). Their
  best scores, medals and "% Unlocked" are saved in your normal save file, which still works without the
  patch. The background layers and Mr. Krabs pictures of "Candid Krabs" are stored smaller (and drawn at full
  size), as at their 3DS size they don't fit in the Wii's memory, and are too big for its graphics chip.
- Credits and Puzzle de Pants in Options: a Credits button on the Options screen shows the game's own
  scrolling credits, which were left in the game for the developers' menu only. The D-pad or the pen scrolls
  them, they carry on by themselves when you let go, and B or the Back tab leaves. Watch them to the end and a
  picture frame appears on the Options wall: pick it to play "Puzzle de Pants", the nanogame cut from the game
  (just for fun: nothing it does is saved).
- Dev Menu (off by default): the game starts in the developers' "Dev Menu", which is still in the game but
  had its controls taken out of the release. See "Dev Menu" below.

Nothing is changed on your disc or in your Wii: the fixes only apply while the game is started with the patch. What you unlock with it is kept in your save.

What's in here:
- riivolution/SquigglePants.xml: the Riivolution patch (its code changes are in the XML itself).
- tools/: what makes the SquigglePants folder. make_files.py runs build.py, which edits Boot.vol's text, fonts
  and credits (italic.py slants the title's letters), puts the "+" logos in menus.vol (logo.py, with
  logo-card-us.png, the high-quality US logo), makes SquigglePantsPlus.vol, and shrinks the big images of
  "Candid Krabs" in Game305.vol (shrink.py). wiivol.py reads the game's file formats; titles.json lists the
  corrected titles.
- source/code/: the patch's code (C and PowerPC assembly), built into unused space in the game's main.dol by
  cave.py with powerpc-linux-gnu-gcc. You only need it to change the patch.
- extras/SS8E78.ini: a Dolphin cheat code for a 100% save (see below).

What 100% needs
All of these, in one save file (with the 100% Completion Fix; without it, the last one needs 101 rounds):
- a gold medal in every Collection and in every Nanogame Replay game;
- the minigames "RetroBob", "Seasons of Sandy" and "Rattle and Roll" at 100, and "Showboating Shower" at 50;
- 75 rounds in Remix;
- 100 rounds in any one Nanogame Replay game.

100% save (Dolphin)
SS8E78.ini holds a Gecko cheat code that fills save file 1 with 100% progress; the game then saves it itself.
1. Copy extras/SS8E78.ini to Dolphin's User/GameSettings folder (or add the code by hand: right-click the game,
   Properties, Gecko Codes, Add New, and paste the lines between the title and the * notes).
2. In Dolphin's settings (General), turn on Enable Cheats. In the game's Properties, Gecko Codes, tick the code.
3. Start the game and pick file 1 (make a new one first if it's empty). Play any one round, for example in
   Nanogame Replay, so the game saves.
4. Untick the code. The file select screen should show 100%, and Movies has all 14 entries.
Back up your save first (Dolphin: right-click the game, Export Wii Save).

Dev Menu
With the Dev Menu option on, the game starts in the developers' menu instead of the logos.
  D-pad up/down: move (hold to scroll)      D-pad left/right: jump 10
  A: pick / open a list                     B (or ".."): back
  + / -: change Game Speed
- Boot: starts the game as normal (logos, title screen). Title Screen and Play Game skip ahead.
- Tests: Hello World, Tweak Test, SfxTrigger Test, Test Canvas, Tablet Test, Test Home Menu, UI Test,
  Art Studio Test, Credits and Movie Alpha Test. These are leftover developer screens; some may not work.
- Untimed Games / Timed Games: how the lists below start a game. Untimed plays the nanogame with no clock;
  press + and - together to restart it, and 1 and 2 together to go back to the menu. Timed doesn't work
  yet (the game freezes), so the menu starts in Untimed.
- Widescreen On/Off, English (cycles German, French, Spanish, Italian, Dutch: the game's own translations).
- UnlockAll: fills all three save files with 100% progress and saves. Back up your save first.
- Microgame List (Game01-Game111, by number), Minigame List (Game1001-1004), and Games per Programmer
  (the nanogames each programmer made: Corwin, Frankel, Lutz, Small and Yoon).
To get back to the Dev Menu after "Boot", restart the game.
source/code/devmenu.c holds the menu's code.

Thanks
To the makers of Riivolution and Dolphin, which made the patch possible to build and to test, and to
Sandmanfan, Berdstep, Rnjwalkthroughs, Andykishore and KyoakuNaKira.

SpongeBob SquigglePants+ is a fan-made patch, not affiliated with or endorsed by Nickelodeon, THQ, WayForward or
uDraw. SpongeBob SquarePants, SpongeBob SquigglePants and all related titles, logos and characters are trademarks
of Viacom International Inc.
